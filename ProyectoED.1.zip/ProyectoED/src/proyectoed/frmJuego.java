/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JFrame.java to edit this template
 */
package proyectoed;


import java.awt.*;
import java.awt.event.*;
import java.io.*;
import javax.swing.*;
import javax.swing.border.*;

/**
 *
 * @author cheve
 */
public class frmJuego extends javax.swing.JFrame {
    private int segundosTranscurridos = 0; 
    private JPanel[][] tablero;
    private Timer timer;
    private int monedas = 800;
    private Cola colaZombies;
    
    private class Cola {
        private class Nodo{
            Zombies zombie;
            Nodo siguiente;
        }
        private Nodo primero; 
        private Nodo ultimo;
        
        public void encolar (Zombies zom){
            Nodo nuevo = new Nodo();
            nuevo.zombie = zom;
            
            if (primero == null){
                primero = ultimo = nuevo;
            }else {
                ultimo.siguiente= nuevo;
                ultimo = nuevo; 
            }
        }
        
        public Zombies desencolar(){
            if(primero == null){
                 return null;
            }
            Zombies zom = primero.zombie;
            primero = primero.siguiente;
            
            if(primero == null){
                ultimo = null;
            }
            return zom;
        }
        
        public boolean isEmpty(){
            return primero == null;
        }
        
        public Zombies verPimero(){
            return primero != null ? primero.zombie : null;
        }
    }
    
    
    public frmJuego() {
        initComponents();        
        setTitle("Plants-Fide");
        setSize(1000, 700);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLayout(new GridLayout(5, 9));
        setLayout(new BorderLayout());
        
        //Oleada
        colaZombies= new Cola();
        nuevaOleada(1);
        
        // Tablero (5x9)
        JPanel panelJuego = new JPanel(new GridLayout(5, 9));
        inicializarJuego(panelJuego); // Pasa el panel para añadir las casillas
        add(panelJuego);
        
        JPanel panelSuperior = new JPanel();
        lbTiempo = new JLabel("Tiempo: 0 segundos" + "Monedas: " + monedas);
        panelSuperior.add(lbTiempo);
       
        add(panelSuperior, BorderLayout.NORTH);
        add (panelJuego, BorderLayout.CENTER);
        
        
        
        //Próximos Zombies
        JPanel pnlAproximacionZombies = new JPanel();
        pnlAproximacionZombies.setBorder(BorderFactory.createTitledBorder("Proxima Oleada de Zombies"));
        add(pnlAproximacionZombies, BorderLayout.SOUTH);
        
        
        // Contador de tiempo
        timer = new Timer (1000, a -> {
         segundosTranscurridos++;
         lbTiempo.setText("Tiempo: " + segundosTranscurridos + " segundos. " + "\nMonedas: " + monedas);
        });
        
        //Mueve Zombies
        if(segundosTranscurridos % 5 == 0){
            caminaZombie();
        }
        
        timer.start();
        
        // 1. Crear panel principal
        JPanel pnlProximosZombies = new JPanel();
        pnlProximosZombies.setLayout(new FlowLayout(FlowLayout.CENTER, 30, 10)); // Espaciado horizontal 30px, vertical 10px
        pnlProximosZombies.setBorder(
    BorderFactory.createTitledBorder(
        BorderFactory.createLineBorder(Color.RED, 2), // Borde rojo grueso
        "OLEADA ZOMBIES",                          // Título
        TitledBorder.CENTER,                         // Alineación
        TitledBorder.TOP,                            // Posición
        new Font("Arial", Font.BOLD, 14),            // Fuente
        Color.WHITE                                  // Color texto
    )
        );
    }
    
    private void nuevaOleada(int numOleada){
        int cant = (numOleada * 2) +3;
        
        for (int i=0; i < cant; i++){
            colaZombies.encolar(new Zombies(6, 3));
        }
        actualizaZombie();
    }
    
    private void caminaZombie (){
        if (!colaZombies.isEmpty()){
            Zombies zom= colaZombies.desencolar();
            actualizaZombie();
        }
    }
    
    private void actualizaZombie(){
        
    }
    
    public void inicializarJuego(JPanel panelJuego){
        tablero = new JPanel[5][9];
        for (int i = 0; i < 5; i++) {
            for (int j = 0; j < 9; j++){
                tablero [i][j] = new JPanel(); 
                tablero[i][j].setBorder(BorderFactory.createLineBorder(Color.BLACK));
                panelJuego.add(tablero[i][j]);
                
            } 
            
        }
    }
    
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jRadioButtonMenuItem1 = new javax.swing.JRadioButtonMenuItem();
        jSeparator1 = new javax.swing.JSeparator();
        jLayeredPane1 = new javax.swing.JLayeredPane();
        btnMenu = new javax.swing.JButton();
        cantMonedas = new javax.swing.JLabel();
        jlbMoneda = new javax.swing.JLabel();
        jlbMoneda1 = new javax.swing.JLabel();
        jlbMoneda2 = new javax.swing.JLabel();
        jlbMoneda3 = new javax.swing.JLabel();
        lblZombieAlien1 = new javax.swing.JLabel();
        lblZombieAlien2 = new javax.swing.JLabel();
        lblZombieAlien3 = new javax.swing.JLabel();
        lblPlantaDos = new javax.swing.JLabel();
        lblPlantaUno = new javax.swing.JLabel();
        lbTiempo = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        jProgressBar1 = new javax.swing.JProgressBar();
        jLabel1 = new javax.swing.JLabel();

        jRadioButtonMenuItem1.setSelected(true);
        jRadioButtonMenuItem1.setText("jRadioButtonMenuItem1");

        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);
        setUndecorated(true);
        setResizable(false);

        jLayeredPane1.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        btnMenu.setBorder(null);
        btnMenu.setContentAreaFilled(false);
        btnMenu.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnMenuActionPerformed(evt);
            }
        });
        jLayeredPane1.add(btnMenu, new org.netbeans.lib.awtextra.AbsoluteConstraints(830, 80, 180, 30));
        jLayeredPane1.add(cantMonedas, new org.netbeans.lib.awtextra.AbsoluteConstraints(80, 160, 40, 20));

        jlbMoneda.setIcon(new javax.swing.ImageIcon(getClass().getResource("/proyectoed/img/monedaPeq.png"))); // NOI18N
        jlbMoneda.setText("jLabel5");
        jLayeredPane1.add(jlbMoneda, new org.netbeans.lib.awtextra.AbsoluteConstraints(-10, 160, 280, 230));

        jlbMoneda1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/proyectoed/img/monedaPeq.png"))); // NOI18N
        jlbMoneda1.setText("jLabel5");
        jLayeredPane1.add(jlbMoneda1, new org.netbeans.lib.awtextra.AbsoluteConstraints(130, 250, 280, 230));

        jlbMoneda2.setIcon(new javax.swing.ImageIcon(getClass().getResource("/proyectoed/img/monedaPeq.png"))); // NOI18N
        jlbMoneda2.setText("jLabel5");
        jLayeredPane1.add(jlbMoneda2, new org.netbeans.lib.awtextra.AbsoluteConstraints(290, 190, 280, 230));

        jlbMoneda3.setIcon(new javax.swing.ImageIcon(getClass().getResource("/proyectoed/img/monedaPeq.png"))); // NOI18N
        jlbMoneda3.setText("jLabel5");
        jLayeredPane1.add(jlbMoneda3, new org.netbeans.lib.awtextra.AbsoluteConstraints(-140, 50, 280, 230));

        lblZombieAlien1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/proyectoed/img/Zombie.png"))); // NOI18N
        lblZombieAlien1.setText("jLabel7");
        jLayeredPane1.add(lblZombieAlien1, new org.netbeans.lib.awtextra.AbsoluteConstraints(900, 160, 100, 140));

        lblZombieAlien2.setIcon(new javax.swing.ImageIcon(getClass().getResource("/proyectoed/img/Zombie.png"))); // NOI18N
        lblZombieAlien2.setText("jLabel7");
        jLayeredPane1.add(lblZombieAlien2, new org.netbeans.lib.awtextra.AbsoluteConstraints(810, 470, 100, 140));

        lblZombieAlien3.setIcon(new javax.swing.ImageIcon(getClass().getResource("/proyectoed/img/Zombie.png"))); // NOI18N
        lblZombieAlien3.setText("jLabel7");
        jLayeredPane1.add(lblZombieAlien3, new org.netbeans.lib.awtextra.AbsoluteConstraints(870, 320, 100, 140));

        lblPlantaDos.setIcon(new javax.swing.ImageIcon(getClass().getResource("/proyectoed/img/BokChoy (1).png"))); // NOI18N
        jLayeredPane1.add(lblPlantaDos, new org.netbeans.lib.awtextra.AbsoluteConstraints(200, 90, -1, 90));

        lblPlantaUno.setIcon(new javax.swing.ImageIcon(getClass().getResource("/proyectoed/img/Peashooter (1).png"))); // NOI18N
        jLayeredPane1.add(lblPlantaUno, new org.netbeans.lib.awtextra.AbsoluteConstraints(140, 90, -1, 90));

        lbTiempo.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        lbTiempo.setForeground(new java.awt.Color(255, 255, 255));
        jLayeredPane1.add(lbTiempo, new org.netbeans.lib.awtextra.AbsoluteConstraints(870, 120, 90, 20));

        jLabel4.setText("jLabel4");
        jLayeredPane1.add(jLabel4, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 0, 420, 110));

        jLabel2.setBackground(new java.awt.Color(51, 51, 51));
        jLabel2.setIcon(new javax.swing.ImageIcon(getClass().getResource("/proyectoed/img/ZombieHead.png"))); // NOI18N
        jLabel2.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.LOWERED));
        jLabel2.setOpaque(true);
        jLayeredPane1.add(jLabel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(530, 100, -1, 30));

        jProgressBar1.setBackground(new java.awt.Color(0, 153, 51));
        jProgressBar1.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.LOWERED));
        jProgressBar1.setFocusable(false);
        jLayeredPane1.add(jProgressBar1, new org.netbeans.lib.awtextra.AbsoluteConstraints(570, 100, 240, 30));

        jLabel1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/proyectoed/img/FondoNivel.png"))); // NOI18N
        jLayeredPane1.add(jLabel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, -1, 785));

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jLayeredPane1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jLayeredPane1)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents
    
    
    
    
    private void btnMenuActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnMenuActionPerformed

        frmMenu m = new frmMenu();
        m.setVisible(true);
        m.iniciar();
        m.getTxtnomUsuario().setText(new frmUsuario().getNom());
        dispose();
        
        /*frmMenu m = new frmMenu();
        m.iniciar();
        m.getTxtnomUsuario().setText(new frmUsuario().getNom());*/
    }//GEN-LAST:event_btnMenuActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(frmJuego.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(frmJuego.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(frmJuego.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(frmJuego.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new frmJuego().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnMenu;
    private javax.swing.JLabel cantMonedas;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLayeredPane jLayeredPane1;
    private javax.swing.JProgressBar jProgressBar1;
    private javax.swing.JRadioButtonMenuItem jRadioButtonMenuItem1;
    private javax.swing.JSeparator jSeparator1;
    private javax.swing.JLabel jlbMoneda;
    private javax.swing.JLabel jlbMoneda1;
    private javax.swing.JLabel jlbMoneda2;
    private javax.swing.JLabel jlbMoneda3;
    private javax.swing.JLabel lbTiempo;
    private javax.swing.JLabel lblPlantaDos;
    private javax.swing.JLabel lblPlantaUno;
    private javax.swing.JLabel lblZombieAlien1;
    private javax.swing.JLabel lblZombieAlien2;
    private javax.swing.JLabel lblZombieAlien3;
    // End of variables declaration//GEN-END:variables

}
