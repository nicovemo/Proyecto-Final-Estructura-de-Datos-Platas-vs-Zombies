/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package proyectoed;

/**
 *
 * @author Nicole Venegas
 */
public class ListaUsuarios {
    private NodoUsuario primero;
    
    private class NodoUsuario {
        String nombre;
        NodoUsuario siguiente;
        
        NodoUsuario(String nombre) {
            this.nombre = nombre;
        }
    }
    
    public void agregarUsuario(String nombre) {
        NodoUsuario nuevo = new NodoUsuario(nombre);
        if (primero == null) {
            primero = nuevo;
        } else {
            NodoUsuario actual = primero;
            while (actual.siguiente != null) {
                actual = actual.siguiente;
            }
            actual.siguiente = nuevo;
        }
    }
    
    public String[] obtenerUsuarios() {
        int cantidad = 0;
        NodoUsuario actual = primero;
        while (actual != null) {
            cantidad++;
            actual = actual.siguiente;
        }
        
        String[] usuarios = new String[cantidad];
        actual = primero;
        for (int i = 0; i < cantidad; i++) {
            usuarios[i] = actual.nombre;
            actual = actual.siguiente;
        }
        return usuarios;
    }
}

