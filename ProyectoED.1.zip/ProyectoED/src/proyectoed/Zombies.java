/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package proyectoed;

import javax.swing.*;

/**
 *
 * @author Nicole Venegas
 */
public class Zombies {
    private int vida; 
    private int ataque;
   // private ImageIcon Zombie;
    private String tipo;

    
    public Zombies (int vida, int ataque ){
        this.vida = vida;
        this.ataque = ataque;
        
        
        //ImageIcon iconZombie = new ImageIcon(getClass().getResource("/proyectoed/img/zombie.png"));
    }

    public int getVida() {
        return vida;
    }

    public int getAtaque() {
        return ataque;
    }

  /*  public ImageIcon getZombie() {
        return Zombie;
    }*/
    
    
    
}
