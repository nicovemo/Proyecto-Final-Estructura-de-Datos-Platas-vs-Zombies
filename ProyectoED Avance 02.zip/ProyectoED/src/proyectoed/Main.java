
package proyectoed;

import java.awt.Font;
import java.awt.FontFormatException;
import java.awt.GraphicsEnvironment;
import java.io.File;
import java.io.IOException;

public class Main {

    public static void main(String[] args) {

        // Iniciar música de fondo
        AudioManager audioManager = AudioManager.getInstance();
        audioManager.playBackgroundMusic("src/proyectoed/img/02.-Crazy-Dave-_Intro-Theme_.wav");

        frmUsuario m = new frmUsuario();
        m.iniciar();

    }

}
