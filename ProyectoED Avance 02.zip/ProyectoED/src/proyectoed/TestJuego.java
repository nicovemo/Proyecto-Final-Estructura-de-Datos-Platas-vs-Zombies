package proyectoed;

/**
 * Clase de prueba para verificar las funcionalidades implementadas
 */
public class TestJuego {

    public static void main(String[] args) {
        System.out.println("=== PRUEBA DEL SISTEMA PLANTS-FIDE ===");

        // Prueba 1: Crear plantas
        System.out.println("\n1. Probando creacion de plantas:");
        Planta planta1 = new PlantaUnoPeashooter();
        Planta planta2 = new PlantaDosBokchoy();

        System.out.println("Planta 1 - Vida: " + planta1.getVida() + ", Costo: " + planta1.getCosto());
        System.out.println("Planta 2 - Vida: " + planta2.getVida() + ", Costo: " + planta2.getCosto());

        // Prueba 2: Crear zombies
        System.out.println("\n2. Probando creacion de zombies:");
        Zombies zombie = new Zombies();
        System.out.println("Zombie - Vida: " + zombie.getVida() + ", Danio: " + zombie.getDano() + ", Recompensa: "
                + zombie.getRecompensa());

        // Prueba 3: Sistema de presupuesto
        System.out.println("\n3. Probando sistema de presupuesto:");
        int presupuesto = 800;
        System.out.println("Presupuesto inicial: " + presupuesto);

        if (presupuesto >= planta1.getCosto()) {
            presupuesto -= planta1.getCosto();
            System.out.println("Compro Planta 1. Presupuesto restante: " + presupuesto);
        }

        if (presupuesto >= planta2.getCosto()) {
            presupuesto -= planta2.getCosto();
            System.out.println("Compro Planta 2. Presupuesto restante: " + presupuesto);
        }

        // Prueba 4: Cola de zombies
        System.out.println("\n4. Probando cola de zombies:");
        ColaZombies cola = new ColaZombies();

        // Generar oleada según la fórmula: (número de oleada * 2) + 3
        int oleada = 1;
        int cantidadZombies = (oleada * 2) + 3;
        System.out.println("Oleada " + oleada + ": " + cantidadZombies + " zombies");

        for (int i = 0; i < cantidadZombies; i++) {
            cola.encolar(new Zombies());
        }

        System.out.println("Zombies en cola: " + cola.getTamanio());

        // Mostrar próximos 3 zombies
        Zombies[] siguientes = cola.obtenerSiguientes(3);
        System.out.println("Proximos 3 zombies:");
        for (int i = 0; i < siguientes.length; i++) {
            System.out.println("  Zombie " + (i + 1) + ": Vida=" + siguientes[i].getVida());
        }

        // Prueba 5: Lista de plantas
        System.out.println("\n5. Probando lista de plantas:");
        ListaPlantas listaPlantas = new ListaPlantas();

        boolean agregada1 = listaPlantas.agregar(planta1, 0, 0);
        boolean agregada2 = listaPlantas.agregar(planta2, 1, 1);

        System.out.println("Planta 1 agregada en (0,0): " + agregada1);
        System.out.println("Planta 2 agregada en (1,1): " + agregada2);
        System.out.println("Hay planta en (0,0): " + listaPlantas.hayPlantaEn(0, 0));
        System.out.println("Hay planta en (2,2): " + listaPlantas.hayPlantaEn(2, 2));

        System.out.println("\n=== PRUEBAS COMPLETADAS ===");
        System.out.println("El sistema esta listo para ser usado en la interfaz grafica.");
    }
}