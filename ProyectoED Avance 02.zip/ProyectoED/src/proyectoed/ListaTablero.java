/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package proyectoed;

import javax.swing.*;

/**
 *
 * @author Nicole Venegas
 */


// LISTA ENLAZADA

public class ListaTablero {
    private Nodo<ListaColumnas> cabeza;

    public void agregar(ListaColumnas fila) {
        Nodo<ListaColumnas> nuevo = new Nodo<>(fila);
        if (cabeza == null) {
            cabeza = nuevo;
        } else {
            Nodo<ListaColumnas> actual = cabeza;
            while (actual.siguiente != null) {
                actual = actual.siguiente;
            }
            actual.siguiente = nuevo;
        }
    }

    public ListaColumnas obtener(int index) {
        Nodo<ListaColumnas> actual = cabeza;
        int contador = 0;
        while (actual != null) {
            if (contador == index) return actual.dato;
            actual = actual.siguiente;
            contador++;
        }
        return null;
    }
}

