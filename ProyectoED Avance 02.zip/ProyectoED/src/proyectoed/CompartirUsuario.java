package proyectoed;


import proyectoed.ListaUsuarios;

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author Nicole Venegas
 */

public class CompartirUsuario {
    public static ListaUsuarios listaUsuarios = new ListaUsuarios();
    
}