package proyectoed;

import javax.swing.*;
import java.awt.*;

/**
 * Prueba del sistema de matriz con JLabels y hover
 */
public class TestMatrizLabels extends JFrame {

    private static final int FILAS = 4;
    private static final int COLUMNAS = 8;
    private JLabel[][] celdasMatriz;
    private int plantaSeleccionada = 0;
    private boolean modoSeleccion = false;

    public TestMatrizLabels() {
        setTitle("Prueba Matriz JLabels - Plants-Fide");
        setSize(800, 600);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);

        // Crear panel principal con fondo
        JPanel mainPanel = new JPanel();
        mainPanel.setLayout(null);
        mainPanel.setBackground(new Color(34, 139, 34)); // Verde oscuro como fondo

        // Crear matriz de JLabels
        celdasMatriz = new JLabel[FILAS][COLUMNAS];
        crearMatrizLabels(mainPanel);

        // Agregar botones de prueba
        JButton btnPlanta1 = new JButton("Planta 1 (Peashooter)");
        btnPlanta1.setBounds(50, 50, 200, 30);
        btnPlanta1.addActionListener(e -> {
            System.out.println("Planta 1 seleccionada");
            plantaSeleccionada = 1;
            modoSeleccion = true;
            mainPanel.setCursor(new Cursor(Cursor.CROSSHAIR_CURSOR));
        });

        JButton btnPlanta2 = new JButton("Planta 2 (Bokchoy)");
        btnPlanta2.setBounds(270, 50, 200, 30);
        btnPlanta2.addActionListener(e -> {
            System.out.println("Planta 2 seleccionada");
            plantaSeleccionada = 2;
            modoSeleccion = true;
            mainPanel.setCursor(new Cursor(Cursor.CROSSHAIR_CURSOR));
        });

        mainPanel.add(btnPlanta1);
        mainPanel.add(btnPlanta2);

        add(mainPanel);
    }

    private void crearMatrizLabels(JPanel panel) {
        int tamanoCelda = 60;
        int offsetX = 50;
        int offsetY = 120;

        for (int fila = 0; fila < FILAS; fila++) {
            for (int columna = 0; columna < COLUMNAS; columna++) {
                JLabel celda = new JLabel();
                celda.setBounds(
                        offsetX + columna * tamanoCelda,
                        offsetY + fila * tamanoCelda,
                        tamanoCelda,
                        tamanoCelda);

                // Configurar apariencia inicial
                celda.setOpaque(true);
                celda.setBackground(new Color(200, 255, 200, 80)); // Verde semi-transparente
                celda.setBorder(BorderFactory.createLineBorder(new Color(255, 255, 0, 200), 2));
                celda.setHorizontalAlignment(SwingConstants.CENTER);
                celda.setVerticalAlignment(SwingConstants.CENTER);

                // Eventos de mouse
                final int f = fila;
                final int c = columna;

                celda.addMouseListener(new java.awt.event.MouseAdapter() {
                    @Override
                    public void mouseEntered(java.awt.event.MouseEvent evt) {
                        if (modoSeleccion && plantaSeleccionada > 0) {
                            celda.setBackground(new Color(255, 255, 0, 150)); // Amarillo
                            celda.setBorder(BorderFactory.createLineBorder(new Color(255, 255, 0, 255), 3));
                        }
                    }

                    @Override
                    public void mouseExited(java.awt.event.MouseEvent evt) {
                        celda.setBackground(new Color(200, 255, 200, 80)); // Verde semi-transparente
                        celda.setBorder(BorderFactory.createLineBorder(new Color(255, 255, 0, 200), 2));
                    }

                    @Override
                    public void mouseClicked(java.awt.event.MouseEvent evt) {
                        if (modoSeleccion && plantaSeleccionada > 0) {
                            System.out.println(" Click en celda (" + f + "," + c + ")");
                            colocarPlantaEnCelda(f, c, celda);
                        }
                    }
                });

                celdasMatriz[fila][columna] = celda;
                panel.add(celda);
            }
        }
    }

    private void colocarPlantaEnCelda(int fila, int columna, JLabel celda) {
        System.out
                .println("🌱 Colocando planta tipo " + plantaSeleccionada + " en celda (" + fila + "," + columna + ")");

        // Obtener la imagen correspondiente
        String rutaImagen = "";
        if (plantaSeleccionada == 1) {
            rutaImagen = "/proyectoed/img/pea-shooter-plant-vs-zombie-ezgif.com-resize.gif";
        } else {
            rutaImagen = "/proyectoed/img/bokchoy-ezgif.com-resize (1).gif";
        }

        // Cargar la imagen
        try {
            ImageIcon icono = new ImageIcon(getClass().getResource(rutaImagen));
            celda.setIcon(icono);
            celda.setHorizontalAlignment(SwingConstants.CENTER);
            celda.setVerticalAlignment(SwingConstants.CENTER);

            System.out.println("Planta colocada exitosamente en celda (" + fila + "," + columna + ")");
        } catch (Exception e) {
            System.out.println("Error al cargar la imagen: " + e.getMessage());
            // Usar emoji como fallback
            celda.setText(plantaSeleccionada == 1 ? "" : "");
            celda.setFont(new Font("Arial", Font.BOLD, 20));
        }

        // Resetear modo de selección
        plantaSeleccionada = 0;
        modoSeleccion = false;
        setCursor(new Cursor(Cursor.DEFAULT_CURSOR));
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            TestMatrizLabels test = new TestMatrizLabels();
            test.setVisible(true);
            System.out.println("=== PRUEBA MATRIZ JLABELS ===");
            System.out.println("Matriz 4x8 con JLabels");
            System.out.println("Hover amarillo al pasar el mouse");
            System.out.println("Click para colocar plantas");
            System.out.println("Imágenes de plantas (Peashooter y Bokchoy)");
        });
    }
}