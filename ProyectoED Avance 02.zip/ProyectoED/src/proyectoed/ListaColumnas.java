/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package proyectoed;

import javax.swing.JLabel;

/**
 *
 * @author Nicole Venegas
 */
public class ListaColumnas {
    private Nodo<JLabel> cabeza;

    public void agregar(JLabel celda) {
        Nodo<JLabel> nuevo = new Nodo<>(celda);
        if (cabeza == null) {
            cabeza = nuevo;
        } else {
            Nodo<JLabel> actual = cabeza;
            while (actual.siguiente != null) {
                actual = actual.siguiente;
            }
            actual.siguiente = nuevo;
        }
    }

    public JLabel obtener(int index) {
        Nodo<JLabel> actual = cabeza;
        int contador = 0;
        while (actual != null) {
            if (contador == index) return actual.dato;
            actual = actual.siguiente;
            contador++;
        }
        return null;
    }
}
