/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package proyectoed;

import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author Nicole Venegas
 */
public class ListaZombiesEnMovimiento {
    private List<ZombieEnMovimiento> zombiesEnMovimiento;

    public ListaZombiesEnMovimiento() {
        this.zombiesEnMovimiento = new ArrayList<>();
    }

    /**
     * Agrega un zombie en movimiento a la lista
     * 
     * @param zombieEnMovimiento El zombie a agregar
     */
    public void agregar(ZombieEnMovimiento zombieEnMovimiento) {
        zombiesEnMovimiento.add(zombieEnMovimiento);
        System.out.println("Zombie agregado a movimiento: " + zombieEnMovimiento);
    }

    /**
     * Remueve un zombie de la lista
     * 
     * @param zombieEnMovimiento El zombie a remover
     */
    public void remover(ZombieEnMovimiento zombieEnMovimiento) {
        zombiesEnMovimiento.remove(zombieEnMovimiento);
        System.out.println("Zombie removido de movimiento: " + zombieEnMovimiento);
    }

    /**
     * Obtiene todos los zombies en movimiento
     * 
     * @return Lista de zombies en movimiento
     */
    public List<ZombieEnMovimiento> obtenerTodos() {
        return new ArrayList<>(zombiesEnMovimiento);
    }

    /**
     * Verifica si hay un zombie activo en una fila específica
     * 
     * @param fila La fila a verificar (0-3)
     * @return true si hay un zombie activo en esa fila, false en caso contrario
     */
    public boolean hayZombieActivoEnFila(int fila) {
        for (ZombieEnMovimiento zombie : zombiesEnMovimiento) {
            if (zombie.isActivo() && zombie.getFila() == fila) {
                return true;
            }
        }
        return false;
    }

    /**
     * Obtiene el zombie activo en una fila específica
     * 
     * @param fila La fila a verificar (0-3)
     * @return El zombie activo en esa fila, o null si no hay ninguno
     */
    public ZombieEnMovimiento obtenerZombieActivoEnFila(int fila) {
        for (ZombieEnMovimiento zombie : zombiesEnMovimiento) {
            if (zombie.isActivo() && zombie.getFila() == fila) {
                return zombie;
            }
        }
        return null;
    }

    /**
     * Verifica si se puede introducir un nuevo zombie en una fila
     * 
     * @param fila La fila a verificar (0-3)
     * @return true si se puede introducir un nuevo zombie, false en caso contrario
     */
    public boolean sePuedeIntroducirNuevoZombieEnFila(int fila) {
        // Verificar el límite global de 3 zombies en pantalla
        if (getCantidadZombiesActivos() >= 3) {
            return false; // Ya hay 3 zombies activos, no se puede introducir más
        }

        ZombieEnMovimiento zombieActivo = obtenerZombieActivoEnFila(fila);
        if (zombieActivo == null) {
            return true; // No hay zombie activo en esa fila
        }

        // Solo se puede introducir si el zombie actual está lo suficientemente lejos
        return zombieActivo.estaLejosParaNuevoZombie();
    }

    /**
     * Obtiene el número de zombies activos
     * 
     * @return El número de zombies activos
     */
    public int getCantidadZombiesActivos() {
        int contador = 0;
        for (ZombieEnMovimiento zombie : zombiesEnMovimiento) {
            if (zombie.isActivo()) {
                contador++;
            }
        }
        return contador;
    }

    /**
     * Verifica si la lista está vacía
     * 
     * @return true si está vacía, false en caso contrario
     */
    public boolean estaVacia() {
        return zombiesEnMovimiento.isEmpty();
    }

    /**
     * Limpia todos los zombies inactivos de la lista
     */
    public void limpiarZombiesInactivos() {
        zombiesEnMovimiento.removeIf(zombie -> !zombie.isActivo());
    }

    /**
     * Verifica si se puede introducir un nuevo zombie considerando el límite global
     * 
     * @return true si se puede introducir un nuevo zombie, false en caso contrario
     */
    public boolean sePuedeIntroducirNuevoZombie() {
        return getCantidadZombiesActivos() < 3;
    }

    /**
     * Obtiene información del estado de todos los zombies en movimiento
     * 
     * @return String con información de todos los zombies
     */
    public String getEstadoZombiesEnMovimiento() {
        if (zombiesEnMovimiento.isEmpty()) {
            return "No hay zombies en movimiento";
        }

        StringBuilder sb = new StringBuilder();
        sb.append("Zombies en movimiento (").append(getCantidadZombiesActivos()).append("/3 activos):\n");

        for (ZombieEnMovimiento zombie : zombiesEnMovimiento) {
            if (zombie.isActivo()) {
                sb.append("  Fila ").append(zombie.getFila())
                        .append(", Columna ").append(zombie.getColumna())
                        .append(", Label ").append(zombie.getNombreLabel())
                        .append(", Pila ").append(zombie.getNumeroPila())
                        .append("\n");
            }
        }

        return sb.toString();
    }
}