package proyectoed;

import javax.swing.*;
import java.awt.*;

/**
 * Clase de utilidad para agregar controles de audio a las pantallas
 */
public class AudioControls {

    /**
     * Crea un panel con controles de audio (pausar/reanudar música de fondo)
     * 
     * @return JPanel con los controles de audio
     */
    public static JPanel createAudioControlPanel() {
        JPanel audioPanel = new JPanel();
        audioPanel.setLayout(new FlowLayout(FlowLayout.RIGHT));
        audioPanel.setOpaque(false);

        // Botón para pausar/reanudar música
        JButton musicToggleButton = new JButton("");
        musicToggleButton.setPreferredSize(new Dimension(40, 30));
        musicToggleButton.setFont(new Font("Arial", Font.BOLD, 16));
        musicToggleButton.setFocusPainted(false);
        musicToggleButton.setBorderPainted(false);
        musicToggleButton.setContentAreaFilled(false);

        // Actualizar el ícono según el estado de la música
        updateMusicButtonIcon(musicToggleButton);

        musicToggleButton.addActionListener(e -> {
            AudioManager audioManager = AudioManager.getInstance();
            if (audioManager.isBackgroundMusicPlaying()) {
                audioManager.pauseBackgroundMusic();
                musicToggleButton.setText("");
            } else {
                audioManager.resumeBackgroundMusic();
                musicToggleButton.setText("");
            }
        });

        audioPanel.add(musicToggleButton);
        return audioPanel;
    }

    /**
     * Actualiza el ícono del botón según el estado de la música
     * 
     * @param button El botón a actualizar
     */
    private static void updateMusicButtonIcon(JButton button) {
        AudioManager audioManager = AudioManager.getInstance();
        if (audioManager.isBackgroundMusicPlaying()) {
            button.setText("");
        } else {
            button.setText("");
        }
    }

    /**
     * Agrega controles de audio a una ventana específica
     * 
     * @param frame La ventana donde agregar los controles
     * @param x     Posición X
     * @param y     Posición Y
     */
    public static void addAudioControlsToFrame(JFrame frame, int x, int y) {
        JPanel audioPanel = createAudioControlPanel();
        audioPanel.setBounds(x, y, 100, 40);

        // Agregar el panel a la ventana
        if (frame.getContentPane() instanceof JLayeredPane) {
            ((JLayeredPane) frame.getContentPane()).add(audioPanel, JLayeredPane.PALETTE_LAYER);
        } else {
            frame.getContentPane().add(audioPanel);
        }

        frame.revalidate();
        frame.repaint();
    }
}