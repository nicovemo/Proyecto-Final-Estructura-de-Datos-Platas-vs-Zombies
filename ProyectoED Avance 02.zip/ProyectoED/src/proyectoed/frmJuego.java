/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JFrame.java to edit this template
 */

package proyectoed;

import proyectoed.*;
import proyectoed.Planta;
import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import java.io.File;
import java.io.IOException;
import javax.sound.sampled.AudioInputStream;
import javax.sound.sampled.AudioSystem;
import javax.sound.sampled.Clip;
import javax.sound.sampled.LineUnavailableException;
import javax.sound.sampled.UnsupportedAudioFileException;

public class frmJuego extends JFrame {

    private ListaZombies zombiesEnJuego;
    private ListaPlantas plantasEnJuego;
    private ColaZombies proximosZombies;
    private PilaZombies pilasZombies;
    private ListaZombiesEnMovimiento zombiesEnMovimiento;

    // Matriz para almacenar las plantas en el tablero
    // [fila][columna] donde:
    // C00 = [0][0], C01 = [0][1], ..., C08 = [0][8]
    // C10 = [1][0], ..., C18 = [1][8]
    // C20 = [2][0], ..., C28 = [2][8]
    // C30 = [3][0], ..., C38 = [3][8]
    private Planta[][] matrizPlantas;

    private int presupuesto = 800;
    private int oleadaActual;
    private int tiempoRestante;
    private boolean enPreparacion;

    private Timer timerPreparacion;
    private Timer timerTurno;
    private String usuario;

    // Variables para selección de plantas
    public int plantaSeleccionada = 0; // 0 = ninguna, 1 = PlantaUno, 2 = PlantaDos
    public boolean modoSeleccion = false;

    public frmJuego(String usuario) {
        initComponents();
        this.usuario = usuario;

        // Asegurar que la música de fondo esté reproduciéndose
        AudioManager audioManager = AudioManager.getInstance();
        if (!audioManager.isBackgroundMusicPlaying()) {
            audioManager.playBackgroundMusic("src/proyectoed/img/02.-Crazy-Dave-_Intro-Theme_.wav");
        }

        // Asignar nombres a los labels del tablero para mapeo a matriz
        // (Esto debe ir después de initComponents para que no se borre al editar el
        // formulario)
        C00.setName("C00");
        C01.setName("C01");
        C02.setName("C02");
        C03.setName("C03");
        C04.setName("C04");
        C05.setName("C05");
        C06.setName("C06");
        C07.setName("C07");
        C08.setName("C08");
        C10.setName("C10");
        C11.setName("C11");
        C12.setName("C12");
        C13.setName("C13");
        C14.setName("C14");
        C15.setName("C15");
        C16.setName("C16");
        C17.setName("C17");
        C18.setName("C18");
        C20.setName("C20");
        C21.setName("C21");
        C22.setName("C22");
        C23.setName("C23");
        C24.setName("C24");
        C25.setName("C25");
        C26.setName("C26");
        C27.setName("C27");
        C28.setName("C28");
        C30.setName("C30");
        C31.setName("C31");
        C32.setName("C32");
        C33.setName("C33");
        C34.setName("C34");
        C35.setName("C35");
        C36.setName("C36");
        C37.setName("C37");
        C38.setName("C38");

        // Inicializar estructuras de datos
        this.zombiesEnJuego = new ListaZombies();
        this.plantasEnJuego = new ListaPlantas();
        this.proximosZombies = new ColaZombies();
        this.pilasZombies = new PilaZombies();
        this.zombiesEnMovimiento = new ListaZombiesEnMovimiento();

        // Inicializar matriz de plantas (4 filas x 9 columnas)
        this.matrizPlantas = new Planta[4][9];

        // Estado inicial del juego
        this.presupuesto = 800;
        this.oleadaActual = 1;
        this.tiempoRestante = 60;
        this.enPreparacion = true;

        inicializarTemporizadores();
        configurarEventosPlantas();
        configurarEventosHover();
        inicializarTablero();
        actualizarUI();
        iniciarJuego();
    }

    private void inicializarTemporizadores() {
        // Timer para fase de preparación (1 segundo)
        timerPreparacion = new Timer(1000, new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                tiempoRestante--;
                actualizarTiempoUI();

                if (tiempoRestante <= 0) {
                    timerPreparacion.stop();
                    iniciarFaseAtaque();
                }
            }
        });

        // Timer para turnos de ataque (1.5 segundos)
        timerTurno = new Timer(1500, new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                ejecutarTurno();
            }
        });

        // Timer para movimiento de zombies (solo cuando no está en preparación)
        Timer timerZombies = new javax.swing.Timer(1000, e -> { // 1000ms = 1 segundo
            if (!enPreparacion) {
                moverZombies();
            }
        });
        timerZombies.start();

        // Timer para movimiento de zombies desde pilas (cada 3 segundos)
        Timer timerZombiesPilas = new javax.swing.Timer(3000, e -> { // 3000ms = 3 segundos
            if (!enPreparacion) {
                moverZombiesEnMovimiento();
            }
        });
        timerZombiesPilas.start();
    }

    private void configurarEventosPlantas() {
        // Configurar eventos para selección de plantas
        lblPlantaUno.addMouseListener(new java.awt.event.MouseAdapter() {
            @Override
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                seleccionarPlanta(1);
            }
        });

        lblPlantaDos.addMouseListener(new java.awt.event.MouseAdapter() {
            @Override
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                seleccionarPlanta(2);
            }
        });

    }

    private void configurarEventosHover() {
        // Configurar efecto hover para todos los labels del tablero
        JLabel[] labels = { C00, C01, C02, C03, C04, C05, C06, C07, C08,
                C10, C11, C12, C13, C14, C15, C16, C17, C18,
                C20, C21, C22, C23, C24, C25, C26, C27, C28,
                C30, C31, C32, C33, C34, C35, C36, C37, C38 };

        for (JLabel label : labels) {
            label.addMouseListener(new java.awt.event.MouseAdapter() {
                @Override
                public void mouseEntered(java.awt.event.MouseEvent evt) {
                    // Solo mostrar hover si hay una planta seleccionada y la celda no tiene planta
                    if (modoSeleccion && plantaSeleccionada > 0 && label.getIcon() == null) {
                        // Cambiar color de fondo a amarillo cuando el mouse entra y ocultar texto
                        label.setOpaque(true);
                        label.setBackground(java.awt.Color.YELLOW);
                        label.setText(""); // Ocultar el texto
                    }
                }

                @Override
                public void mouseExited(java.awt.event.MouseEvent evt) {
                    // Solo restaurar si había hover activo y la celda no tiene planta
                    if (modoSeleccion && plantaSeleccionada > 0 && label.getIcon() == null) {
                        // Quitar el color de fondo cuando el mouse sale y mantener texto vacío
                        label.setOpaque(false);
                        label.setBackground(null);
                        label.setText(""); // Mantener el texto vacío, no restaurar "jLabel1"
                    }
                }

                @Override
                public void mouseClicked(java.awt.event.MouseEvent evt) {
                    // Solo permitir colocar planta si hay una seleccionada y la celda no tiene
                    // planta
                    if (modoSeleccion && plantaSeleccionada > 0 && label.getIcon() == null) {
                        colocarPlanta(label);
                    }
                }
            });
        }
    }

    private void inicializarTablero() {
        // Configurar todos los JLabels del tablero con un tamaño fijo para las imágenes
        JLabel[] labels = { C00, C01, C02, C03, C04, C05, C06, C07, C08,
                C10, C11, C12, C13, C14, C15, C16, C17, C18,
                C20, C21, C22, C23, C24, C25, C26, C27, C28,
                C30, C31, C32, C33, C34, C35, C36, C37, C38 };

        for (JLabel label : labels) {
            // Establecer un tamaño preferido para que las imágenes se redimensionen
            // correctamente
            label.setPreferredSize(new Dimension(70, 80));
            label.setMinimumSize(new Dimension(70, 80));
            label.setMaximumSize(new Dimension(70, 80));

            // Configurar el layout del icono para que se centre
            label.setHorizontalAlignment(SwingConstants.CENTER);
            label.setVerticalAlignment(SwingConstants.CENTER);
        }
    }

    private void seleccionarPlanta(int tipo) {
        plantaSeleccionada = tipo;
        modoSeleccion = true;
        pnlTablero.setCursor(new java.awt.Cursor(java.awt.Cursor.CROSSHAIR_CURSOR));

        String nombrePlanta = (tipo == 1) ? "PlantaUno (Peashooter)" : "PlantaDos (Bokchoy)";
        System.out.println("🌱 Planta seleccionada: " + nombrePlanta);
        System.out.println("💰 Costo: " + (tipo == 1 ? 250 : 400) + " monedas");
        System.out.println("💡 Click en el tablero para colocar la planta");
    }

    /**
     * Mapea un label del tablero a su posición en la matriz
     * 
     * @param label El JLabel del tablero (C00, C01, C10, C11, C20, C21, C30, C31)
     * @return Un array de 2 elementos [fila, columna] o null si el label no es
     *         válido
     */
    private int[] mapearLabelAMatriz(JLabel label) {
        String nombreLabel = label.getName();
        if (nombreLabel == null) {
            return null;
        }

        switch (nombreLabel) {
            case "C00":
                return new int[] { 0, 0 };
            case "C01":
                return new int[] { 0, 1 };
            case "C02":
                return new int[] { 0, 2 };
            case "C03":
                return new int[] { 0, 3 };
            case "C04":
                return new int[] { 0, 4 };
            case "C05":
                return new int[] { 0, 5 };
            case "C06":
                return new int[] { 0, 6 };
            case "C07":
                return new int[] { 0, 7 };
            case "C08":
                return new int[] { 0, 8 };
            case "C10":
                return new int[] { 1, 0 };
            case "C11":
                return new int[] { 1, 1 };
            case "C12":
                return new int[] { 1, 2 };
            case "C13":
                return new int[] { 1, 3 };
            case "C14":
                return new int[] { 1, 4 };
            case "C15":
                return new int[] { 1, 5 };
            case "C16":
                return new int[] { 1, 6 };
            case "C17":
                return new int[] { 1, 7 };
            case "C18":
                return new int[] { 1, 8 };
            case "C20":
                return new int[] { 2, 0 };
            case "C21":
                return new int[] { 2, 1 };
            case "C22":
                return new int[] { 2, 2 };
            case "C23":
                return new int[] { 2, 3 };
            case "C24":
                return new int[] { 2, 4 };
            case "C25":
                return new int[] { 2, 5 };
            case "C26":
                return new int[] { 2, 6 };
            case "C27":
                return new int[] { 2, 7 };
            case "C28":
                return new int[] { 2, 8 };
            case "C30":
                return new int[] { 3, 0 };
            case "C31":
                return new int[] { 3, 1 };
            case "C32":
                return new int[] { 3, 2 };
            case "C33":
                return new int[] { 3, 3 };
            case "C34":
                return new int[] { 3, 4 };
            case "C35":
                return new int[] { 3, 5 };
            case "C36":
                return new int[] { 3, 6 };
            case "C37":
                return new int[] { 3, 7 };
            case "C38":
                return new int[] { 3, 8 };
            default:
                return null;
        }
    }

    /**
     * Obtiene la planta en una posición específica de la matriz
     * 
     * @param fila    Fila de la matriz (0-3)
     * @param columna Columna de la matriz (0-1)
     * @return La planta en esa posición o null si está vacía
     */
    public Planta obtenerPlanta(int fila, int columna) {
        if (fila >= 0 && fila < 4 && columna >= 0 && columna < 9) {
            return matrizPlantas[fila][columna];
        }
        return null;
    }

    /**
     * Obtiene un JLabel del tablero por su nombre
     * 
     * @param nombreLabel El nombre del label (ej: "C08", "C07", etc.)
     * @return El JLabel correspondiente, o null si no se encuentra
     */
    private JLabel obtenerLabelPorNombre(String nombreLabel) {
        switch (nombreLabel) {
            case "C00":
                return C00;
            case "C01":
                return C01;
            case "C02":
                return C02;
            case "C03":
                return C03;
            case "C04":
                return C04;
            case "C05":
                return C05;
            case "C06":
                return C06;
            case "C07":
                return C07;
            case "C08":
                return C08;
            case "C10":
                return C10;
            case "C11":
                return C11;
            case "C12":
                return C12;
            case "C13":
                return C13;
            case "C14":
                return C14;
            case "C15":
                return C15;
            case "C16":
                return C16;
            case "C17":
                return C17;
            case "C18":
                return C18;
            case "C20":
                return C20;
            case "C21":
                return C21;
            case "C22":
                return C22;
            case "C23":
                return C23;
            case "C24":
                return C24;
            case "C25":
                return C25;
            case "C26":
                return C26;
            case "C27":
                return C27;
            case "C28":
                return C28;
            case "C30":
                return C30;
            case "C31":
                return C31;
            case "C32":
                return C32;
            case "C33":
                return C33;
            case "C34":
                return C34;
            case "C35":
                return C35;
            case "C36":
                return C36;
            case "C37":
                return C37;
            case "C38":
                return C38;
            default:
                return null;
        }
    }

    /**
     * Coloca una planta en la matriz y actualiza la interfaz visual
     * 
     * @param celda El JLabel donde se colocará la planta
     */
    private void colocarPlanta(JLabel celda) {
        int costo = (plantaSeleccionada == 1) ? 250 : 400;

        // Verificar si hay suficientes monedas
        if (presupuesto >= costo) {
            // Verificar si la celda ya tiene una planta
            if (celda.getIcon() != null) {
                System.out.println("❌ Esta celda ya tiene una planta colocada");
                resetearSeleccion();
                return;
            }

            // Mapear el label a la posición en la matriz
            int[] posicion = mapearLabelAMatriz(celda);
            if (posicion == null) {
                System.out.println("❌ Error: No se pudo mapear la posición del label");
                resetearSeleccion();
                return;
            }

            int fila = posicion[0];
            int columna = posicion[1];

            // Verificar si la posición en la matriz ya está ocupada
            if (matrizPlantas[fila][columna] != null) {
                System.out.println("❌ Esta posición ya tiene una planta en la matriz");
                resetearSeleccion();
                return;
            }

            // Crear y colocar la planta
            Planta nuevaPlanta = PlantaFactory.crearPlanta(plantaSeleccionada);
            if (nuevaPlanta != null) {
                // Guardar la planta en la matriz
                matrizPlantas[fila][columna] = nuevaPlanta;

                // Cargar y configurar la imagen correspondiente
                String rutaImagen = (plantaSeleccionada == 1) ? "/proyectoed/img/uno.png"
                        : "/proyectoed/img/Hd_bonk.png";

                try {
                    ImageIcon iconoOriginal = new ImageIcon(getClass().getResource(rutaImagen));
                    Image imagenOriginal = iconoOriginal.getImage();

                    // Redimensionar la imagen a un tamaño fijo (70x80 como se definió en el layout)
                    Image imagenRedimensionada = imagenOriginal.getScaledInstance(70, 80, Image.SCALE_SMOOTH);

                    // Limpiar el estado de hover ANTES de colocar la imagen
                    celda.setOpaque(false);
                    celda.setBackground(null);

                    ImageIcon iconoFinal = new ImageIcon(imagenRedimensionada);
                    celda.setIcon(iconoFinal);
                    celda.setText(""); // Limpiar el texto
                    celda.setFont(null); // Asegurar que no haya fuente de texto

                    // Asegurar que el JLabel esté configurado correctamente para mostrar la imagen
                    celda.setHorizontalAlignment(SwingConstants.CENTER);
                    celda.setVerticalAlignment(SwingConstants.CENTER);

                    // Forzar la repintura del JLabel para asegurar que la imagen se muestre
                    celda.revalidate();
                    celda.repaint();

                    // Verificar que el texto esté limpio después de la repintura
                    SwingUtilities.invokeLater(() -> {
                        celda.setText("");
                    });

                    System.out.println("🌱 Planta colocada en celda: " + celda.getName() + " -> Matriz[" + fila + "]["
                            + columna + "]");
                    System.out.println("💰 Costo: " + costo + " monedas");
                    System.out.println("🖼️ Imagen aplicada: " + rutaImagen);
                    System.out.println("📊 Estado de la matriz:");
                    imprimirEstadoMatriz();

                    // Actualizar presupuesto
                    presupuesto -= costo;
                    actualizarUI();

                    // Resetear selección
                    resetearSeleccion();
                } catch (Exception e) {
                    System.out.println("❌ Error al cargar la imagen: " + e.getMessage());
                    // Si hay error, limpiar la posición en la matriz
                    matrizPlantas[fila][columna] = null;
                    resetearSeleccion();
                }
            }
        } else {
            System.out.println("❌ No hay suficientes monedas. Necesitas: " + costo + ", tienes: " + presupuesto);
            resetearSeleccion();
        }
    }

    /**
     * Imprime el estado actual de la matriz de plantas para debugging
     */
    public void imprimirEstadoMatriz() {
        System.out.println("┌" + "─────┬".repeat(8) + "─────┐");
        for (int fila = 0; fila < 4; fila++) {
            System.out.print("│");
            for (int columna = 0; columna < 9; columna++) {
                Planta planta = matrizPlantas[fila][columna];
                if (planta != null) {
                    String tipo = (planta instanceof PlantaUnoPeashooter) ? "P1" : "P2";
                    System.out.print(" " + tipo + " │");
                } else {
                    System.out.print("   │");
                }
            }
            if (fila < 3) {
                System.out.println("\n├" + "─────┼".repeat(8) + "─────┤");
            }
        }
        System.out.println("\n└" + "─────┴".repeat(8) + "─────┘");
    }

    /**
     * Obtiene el estado completo de la matriz de plantas
     * 
     * @return Una copia de la matriz actual
     */
    public Planta[][] obtenerEstadoMatriz() {
        Planta[][] copia = new Planta[4][9];
        for (int fila = 0; fila < 4; fila++) {
            for (int columna = 0; columna < 9; columna++) {
                copia[fila][columna] = matrizPlantas[fila][columna];
            }
        }
        return copia;
    }

    /**
     * Limpia toda la matriz de plantas y la interfaz visual
     */
    public void limpiarMatriz() {
        for (int fila = 0; fila < 4; fila++) {
            for (int columna = 0; columna < 9; columna++) {
                matrizPlantas[fila][columna] = null;
            }
        }

        // Limpiar la interfaz visual
        JLabel[] labels = { C00, C01, C02, C03, C04, C05, C06, C07, C08,
                C10, C11, C12, C13, C14, C15, C16, C17, C18,
                C20, C21, C22, C23, C24, C25, C26, C27, C28,
                C30, C31, C32, C33, C34, C35, C36, C37, C38 };
        for (JLabel label : labels) {
            label.setIcon(null);
            label.setText("");
        }

        System.out.println("🧹 Matriz de plantas limpiada");
    }

    /**
     * Verifica si una posición específica en la matriz está ocupada
     * 
     * @param fila    Fila de la matriz (0-3)
     * @param columna Columna de la matriz (0-1)
     * @return true si la posición está ocupada, false si está vacía
     */
    public boolean posicionOcupada(int fila, int columna) {
        if (fila >= 0 && fila < 4 && columna >= 0 && columna < 9) {
            return matrizPlantas[fila][columna] != null;
        }
        return false;
    }

    /**
     * Muestra información detallada sobre el estado de la matriz
     */
    public void mostrarInformacionMatriz() {
        System.out.println("📊 INFORMACIÓN DETALLADA DE LA MATRIZ:");
        System.out.println("======================================");

        for (int fila = 0; fila < 4; fila++) {
            for (int columna = 0; columna < 9; columna++) {
                Planta planta = matrizPlantas[fila][columna];
                String posicion = "[" + fila + "][" + columna + "]";

                if (planta != null) {
                    String tipo = (planta instanceof PlantaUnoPeashooter) ? "PlantaUnoPeashooter" : "PlantaDosBokchoy";
                    System.out.println("Posición " + posicion + ": " + tipo);
                } else {
                    System.out.println("Posición " + posicion + ": VACÍA");
                }
            }
        }

        System.out.println("======================================");
    }

    private void resetearSeleccion() {
        plantaSeleccionada = 0;
        modoSeleccion = false;
        pnlTablero.setCursor(new java.awt.Cursor(java.awt.Cursor.DEFAULT_CURSOR));
        System.out.println("🔄 Selección de planta reseteada");
    }

    private void moverZombies() {
        // Solo mover zombies si no está en fase de preparación
        if (enPreparacion) {
            return;
        }

        // Mover todos los zombies en el juego
        zombiesEnJuego.mover(plantasEnJuego);

        // Verificar si algún zombie llegó al final
        if (zombiesEnJuego.algunoLlegoAlFinal()) {
            finDelJuego(false); // Derrota
            return;
        }

        // Verificar si no quedan zombies y la cola está vacía
        if (zombiesEnJuego.estaVacia() && proximosZombies.estaVacia() && pilasZombies.todasLasPilasVacias()) {
            oleadaCompletada();
        }

        System.out.println("🧟 Zombies movidos - Zombies en juego: " + zombiesEnJuego.getSize());
    }

    public void iniciarJuego() {
        System.out.println("🎮 Iniciando juego para usuario: " + usuario);
        generarOleadaZombies();
        actualizarProximosZombiesUI();

        // Iniciar el timer de preparación
        timerPreparacion.start();
        System.out.println("⏰ Iniciando fase de preparación - Tiempo restante: " + tiempoRestante + " segundos");
    }

    private void generarOleadaZombies() {
        int cantidadZombies = (oleadaActual * 2) + 3;
        System.out.println("🧟 Generando oleada " + oleadaActual + " con " + cantidadZombies + " zombies");

        // Llenar las pilas de zombies de manera aleatoria
        pilasZombies.llenarPilasAleatoriamente(cantidadZombies);

        // También mantener la cola para compatibilidad con el código existente
        for (int i = 0; i < cantidadZombies; i++) {
            Zombies zombie = new Zombies();
            proximosZombies.encolar(zombie);
        }
    }

    /**
     * Agrega una nueva oleada de zombies a las pilas existentes sin limpiarlas
     */
    private void agregarNuevaOleadaAPilas() {
        int cantidadZombies = (oleadaActual * 2) + 3;
        System.out.println("🧟 Agregando nueva oleada " + oleadaActual + " con " + cantidadZombies
                + " zombies a las pilas existentes");

        // Agregar zombies a las pilas existentes sin limpiarlas
        pilasZombies.agregarOleadaAPilas(cantidadZombies);

        // También mantener la cola para compatibilidad con el código existente
        for (int i = 0; i < cantidadZombies; i++) {
            Zombies zombie = new Zombies();
            proximosZombies.encolar(zombie);
        }
    }

    private void actualizarProximosZombiesUI() {
        Zombies[] proximos = proximosZombies.obtenerSiguientes(3);
        System.out.println("👀 Próximos 3 zombies:");
        for (int i = 0; i < proximos.length; i++) {
            if (proximos[i] != null) {
                System.out.println("  Zombie " + (i + 1) + ": Vida=" + proximos[i].getVida());
            }
        }
    }

    /**
     * Actualiza la interfaz visual de las 4 pilas de zombies
     * Muestra la imagen Zombie.png en los labels correspondientes según el
     * contenido de cada pila
     */
    private void actualizarPilasZombiesUI() {
        // Verificar si hay 3 zombies en el tablero
        boolean hay3ZombiesEnTablero = zombiesEnMovimiento.getCantidadZombiesActivos() >= 3;

        if (hay3ZombiesEnTablero) {
            // Si hay 3 zombies en el tablero, ocultar todos los zombies de las pilas
            C09Z.setIcon(null);
            C09Z.setText("");
            C19Z.setIcon(null);
            C19Z.setText("");
            C29Z.setIcon(null);
            C29Z.setText("");
            C39Z.setIcon(null);
            C39Z.setText("");
            System.out.println("🧟 Ocultando zombies de pilas - hay " + zombiesEnMovimiento.getCantidadZombiesActivos()
                    + " zombies en el tablero");
            return;
        }

        // Cargar la imagen del zombie
        ImageIcon iconoZombie = null;
        try {
            iconoZombie = new ImageIcon(getClass().getResource("/proyectoed/img/Zombie.png"));
            if (iconoZombie.getImage() == null) {
                System.out.println("❌ No se pudo cargar la imagen Zombie.png");
                return;
            }
        } catch (Exception e) {
            System.out.println("❌ Error al cargar la imagen Zombie.png: " + e.getMessage());
            return;
        }

        // Redimensionar la imagen para que se ajuste a los labels
        Image imagenOriginal = iconoZombie.getImage();
        Image imagenRedimensionada = imagenOriginal.getScaledInstance(70, 80, Image.SCALE_SMOOTH);
        ImageIcon iconoFinal = new ImageIcon(imagenRedimensionada);

        // Actualizar cada label según el contenido de su pila correspondiente
        // Pila 1 -> C09Z
        if (!pilasZombies.pilaVacia(1)) {
            C09Z.setIcon(iconoFinal);
            C09Z.setText(""); // Limpiar texto
            System.out.println("🧟 Pila 1: Mostrando zombie en C09Z");
        } else {
            C09Z.setIcon(null);
            C09Z.setText("");
        }

        // Pila 2 -> C19Z
        if (!pilasZombies.pilaVacia(2)) {
            C19Z.setIcon(iconoFinal);
            C19Z.setText(""); // Limpiar texto
            System.out.println("🧟 Pila 2: Mostrando zombie en C19Z");
        } else {
            C19Z.setIcon(null);
            C19Z.setText("");
        }

        // Pila 3 -> C29Z
        if (!pilasZombies.pilaVacia(3)) {
            C29Z.setIcon(iconoFinal);
            C29Z.setText(""); // Limpiar texto
            System.out.println("🧟 Pila 3: Mostrando zombie en C29Z");
        } else {
            C29Z.setIcon(null);
            C29Z.setText("");
        }

        // Pila 4 -> C39Z
        if (!pilasZombies.pilaVacia(4)) {
            C39Z.setIcon(iconoFinal);
            C39Z.setText(""); // Limpiar texto
            System.out.println("🧟 Pila 4: Mostrando zombie en C39Z");
        } else {
            C39Z.setIcon(null);
            C39Z.setText("");
        }

        // Mostrar estado de las pilas en consola
        System.out.println("📊 Estado de pilas: " + pilasZombies.getEstadoPilas());
    }

    private void iniciarFaseAtaque() {
        System.out.println("⚔️ Iniciando fase de ataque!");
        enPreparacion = false;
        timerTurno.start();

        // Actualizar la UI de las pilas de zombies cuando termine la preparación
        actualizarPilasZombiesUI();

        // Reproducir sonido de zombies
        reproducirSonido("src/proyectoed/img/zombies.wav");

        // Introducir zombies desde las pilas hacia el tablero
        introducirZombiesDesdePilas();
    }

    private void ejecutarTurno() {
        System.out.println("🔄 Ejecutando turno...");

        // Intentar introducir zombies desde las pilas
        introducirZombiesDesdePilas();

        // También mantener la funcionalidad existente con la cola
        if (!proximosZombies.estaVacia()) {
            introducirZombieAlJuego();
        }

        // Actualizar la UI de próximos zombies
        actualizarProximosZombiesUI();
    }

    private void oleadaCompletada() {
        oleadaActual++;
        System.out.println("🎉 Oleada " + (oleadaActual - 1) + " completada!");
        System.out.println("🔄 Iniciando oleada " + oleadaActual);

        // Reiniciar para la nueva oleada
        enPreparacion = true;
        tiempoRestante = 60;
        timerTurno.stop();
        timerPreparacion.start();

        // Generar nueva oleada y agregar a las pilas existentes (no reemplazar)
        agregarNuevaOleadaAPilas();
        actualizarProximosZombiesUI();

        System.out.println("⏰ Nueva fase de preparación iniciada - Tiempo restante: " + tiempoRestante + " segundos");
    }

    private void finDelJuego(boolean victoria) {
        // Detener todos los timers
        if (timerPreparacion != null) {
            timerPreparacion.stop();
        }
        if (timerTurno != null) {
            timerTurno.stop();
        }

        // Limpiar las pilas de zombies solo cuando el juego termine completamente
        C09Z.setIcon(null);
        C19Z.setIcon(null);
        C29Z.setIcon(null);
        C39Z.setIcon(null);
        C09Z.setText("");
        C19Z.setText("");
        C29Z.setText("");
        C39Z.setText("");

        if (victoria) {
            System.out.println("🏆 ¡Victoria! Has derrotado a todos los zombies");
            // Aquí se podría abrir la ventana de victoria
        } else {
            System.out.println("💀 Derrota. Los zombies han llegado a tu casa");
            // Aquí se podría abrir la ventana de derrota
        }
    }

    private void actualizarUI() {
        cantMonedas.setText(String.valueOf(presupuesto));
        actualizarTiempoUI();
    }

    private void actualizarTiempoUI() {
        lbTiempo.setText(String.format("%02d:%02d", tiempoRestante / 60, tiempoRestante % 60));
    }

    private void introducirZombieAlJuego() {
        // Intentar obtener un zombie de las pilas primero
        Zombies zombie = obtenerZombieDePilaAleatoria();

        if (zombie != null) {
            // Colocar zombie en una fila aleatoria al final del tablero
            int fila = (int) (Math.random() * 4); // 4 filas (0-3)
            int columna = 7; // Última columna del tablero

            zombiesEnJuego.agregar(zombie, fila, columna);
            System.out.println("🧟 Zombie de pila introducido en fila " + fila + ", columna " + columna);

            // No actualizar la UI de las pilas para que los zombies permanezcan visibles
            // actualizarPilasZombiesUI();
        } else if (!proximosZombies.estaVacia()) {
            // Si no hay zombies en las pilas, usar la cola como respaldo
            zombie = proximosZombies.desencolar();
            int fila = (int) (Math.random() * 4);
            int columna = 7;

            zombiesEnJuego.agregar(zombie, fila, columna);
            System.out.println("🧟 Zombie de cola introducido en fila " + fila + ", columna " + columna);
        }
    }

    /**
     * Obtiene un zombie de una pila aleatoria que no esté vacía
     * 
     * @return El zombie obtenido, o null si todas las pilas están vacías
     */
    private Zombies obtenerZombieDePilaAleatoria() {
        if (pilasZombies.todasLasPilasVacias()) {
            return null;
        }

        // Crear una lista de pilas no vacías
        java.util.List<Integer> pilasDisponibles = new java.util.ArrayList<>();
        for (int i = 1; i <= 4; i++) {
            if (!pilasZombies.pilaVacia(i)) {
                pilasDisponibles.add(i);
            }
        }

        // Seleccionar una pila aleatoria de las disponibles
        if (!pilasDisponibles.isEmpty()) {
            int pilaAleatoria = pilasDisponibles.get((int) (Math.random() * pilasDisponibles.size()));
            Zombies zombie = pilasZombies.obtenerZombieDePila(pilaAleatoria);
            System.out.println("🧟 Zombie obtenido de Pila " + pilaAleatoria);
            return zombie;
        }

        return null;
    }

    /**
     * Introduce un zombie desde una pila hacia el tablero
     * 
     * @param numeroPila El número de pila (1-4)
     * @param fila       La fila donde se introducirá el zombie (0-3)
     */
    private void introducirZombieDesdePila(int numeroPila, int fila) {
        // Verificar si se puede introducir un nuevo zombie en esta fila
        if (!zombiesEnMovimiento.sePuedeIntroducirNuevoZombieEnFila(fila)) {
            System.out.println("🧟 No se puede introducir zombie en fila " + fila + " - hay uno muy cerca");
            return;
        }

        // Obtener zombie de la pila específica
        Zombies zombie = pilasZombies.obtenerZombieDePila(numeroPila);
        if (zombie == null) {
            System.out.println("🧟 Pila " + numeroPila + " está vacía");
            return;
        }

        // Crear zombie en movimiento
        ZombieEnMovimiento zombieEnMovimiento = new ZombieEnMovimiento(zombie, fila, numeroPila);

        // Obtener el label inicial (C08, C18, C28, C38)
        String nombreLabelInicial = "C" + fila + "8";
        JLabel labelInicial = obtenerLabelPorNombre(nombreLabelInicial);

        if (labelInicial == null) {
            System.out.println("❌ No se pudo encontrar el label: " + nombreLabelInicial);
            return;
        }

        // Mostrar el zombie en el label inicial
        mostrarZombieEnLabel(labelInicial);
        zombieEnMovimiento.setLabelActual(labelInicial);

        // Agregar a la lista de zombies en movimiento
        zombiesEnMovimiento.agregar(zombieEnMovimiento);

        // Actualizar la UI de las pilas después de introducir un zombie
        actualizarPilasZombiesUI();

        System.out.println("🧟 Zombie introducido desde Pila " + numeroPila + " en fila " + fila +
                " en posición " + nombreLabelInicial);
    }

    /**
     * Muestra la imagen del zombie en un label específico
     * 
     * @param label El label donde mostrar el zombie
     */
    private void mostrarZombieEnLabel(JLabel label) {
        // Cargar la imagen del zombie
        ImageIcon iconoZombie = null;
        try {
            iconoZombie = new ImageIcon(getClass().getResource("/proyectoed/img/Zombie.png"));
            if (iconoZombie.getImage() == null) {
                System.out.println("❌ No se pudo cargar la imagen Zombie.png");
                return;
            }
        } catch (Exception e) {
            System.out.println("❌ Error al cargar la imagen Zombie.png: " + e.getMessage());
            return;
        }

        // Redimensionar la imagen
        Image imagenOriginal = iconoZombie.getImage();
        Image imagenRedimensionada = imagenOriginal.getScaledInstance(70, 80, Image.SCALE_SMOOTH);
        ImageIcon iconoFinal = new ImageIcon(imagenRedimensionada);

        // Mostrar el zombie en el label
        label.setIcon(iconoFinal);
        label.setText("");
    }

    /**
     * Limpia un label (quita el zombie)
     * 
     * @param label El label a limpiar
     */
    private void limpiarLabel(JLabel label) {
        label.setIcon(null);
        label.setText("");
    }

    /**
     * Introduce zombies desde las pilas hacia el tablero
     */
    private void introducirZombiesDesdePilas() {
        // Verificar el límite global de 3 zombies en pantalla
        if (!zombiesEnMovimiento.sePuedeIntroducirNuevoZombie()) {
            System.out.println("🧟 Límite de 3 zombies alcanzado - no se pueden introducir más zombies");
            return;
        }

        // Intentar introducir un zombie de cada pila en su fila correspondiente
        for (int pila = 1; pila <= 4; pila++) {
            int fila = pila - 1; // Pila 1 -> Fila 0, Pila 2 -> Fila 1, etc.

            // Verificar si la pila tiene zombies y si se puede introducir en esa fila
            if (!pilasZombies.pilaVacia(pila) && zombiesEnMovimiento.sePuedeIntroducirNuevoZombieEnFila(fila)) {
                introducirZombieDesdePila(pila, fila);

                // Verificar nuevamente el límite después de introducir un zombie
                if (!zombiesEnMovimiento.sePuedeIntroducirNuevoZombie()) {
                    System.out.println("🧟 Límite de 3 zombies alcanzado después de introducir zombie de Pila " + pila);
                    break;
                }
            }
        }
    }

    /**
     * Mueve todos los zombies en movimiento
     */
    private void moverZombiesEnMovimiento() {
        if (enPreparacion) {
            return; // No mover zombies durante la preparación
        }

        java.util.List<ZombieEnMovimiento> zombies = zombiesEnMovimiento.obtenerTodos();

        for (ZombieEnMovimiento zombie : zombies) {
            if (!zombie.isActivo()) {
                continue; // Saltar zombies inactivos
            }

            // Verificar si hay una planta en la posición siguiente
            int[] posicionActual = zombie.getPosicionMatriz();
            int fila = posicionActual[0];
            int columna = posicionActual[1];

            // Verificar si hay una planta en la posición actual o en la siguiente
            if (columna > 0) { // Si no está en la columna más a la izquierda
                Planta plantaEnPosicionActual = matrizPlantas[fila][columna];
                Planta plantaEnPosicionSiguiente = matrizPlantas[fila][columna - 1];

                if (plantaEnPosicionActual != null || plantaEnPosicionSiguiente != null) {
                    System.out.println("🧟 Zombie en " + zombie.getNombreLabel() + " se detuvo por planta");
                    zombie.setActivo(false);
                    continue;
                }
            }

            // Verificar si llegó al final del tablero
            if (columna <= 0) {
                System.out.println("🧟 Zombie en " + zombie.getNombreLabel() + " llegó al final");
                zombie.setActivo(false);
                finDelJuego(false); // Derrota
                continue;
            }

            // Limpiar la posición actual
            if (zombie.getLabelActual() != null) {
                limpiarLabel(zombie.getLabelActual());
            }

            // Mover el zombie
            boolean seMovio = zombie.mover();
            if (seMovio) {
                // Obtener el nuevo label
                String nuevoNombreLabel = zombie.getNombreLabel();
                JLabel nuevoLabel = obtenerLabelPorNombre(nuevoNombreLabel);

                if (nuevoLabel != null) {
                    // Mostrar el zombie en la nueva posición
                    mostrarZombieEnLabel(nuevoLabel);
                    zombie.setLabelActual(nuevoLabel);

                    System.out.println("🧟 Zombie movido a " + nuevoNombreLabel);
                }
            }
        }

        // Limpiar zombies inactivos
        zombiesEnMovimiento.limpiarZombiesInactivos();

        // Actualizar la UI de las pilas después de mover zombies
        actualizarPilasZombiesUI();

        // Mostrar estado de zombies en movimiento
        System.out.println(zombiesEnMovimiento.getEstadoZombiesEnMovimiento());
    }

    private void actualizarPosicionZombie(Zombies z) {
        // Actualizar posición visual del zombie
    }

    /**
     * Reproduce un archivo de sonido MP3 o WAV una vez.
     * 
     * @param path Ruta relativa o absoluta del archivo de sonido
     */
    private void reproducirSonido(String path) {
        // Usar AudioManager para efectos de sonido (no interrumpe la música de fondo)
        AudioManager.getInstance().playSoundEffect(path);
    }

    // Clases internas necesarias
    private static class PlantaFactory {
        public static Planta crearPlanta(int tipo) {
            switch (tipo) {
                case 1:
                    return new PlantaUnoPeashooter();
                case 2:
                    return new PlantaDosBokchoy();
                default:
                    return null;
            }
        }
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated
    // <editor-fold defaultstate="collapsed" desc="Generated
    // <editor-fold defaultstate="collapsed" desc="Generated
    // <editor-fold defaultstate="collapsed" desc="Generated
    // <editor-fold defaultstate="collapsed" desc="Generated
    // <editor-fold defaultstate="collapsed" desc="Generated
    // <editor-fold defaultstate="collapsed" desc="Generated
    // <editor-fold defaultstate="collapsed" desc="Generated
    // <editor-fold defaultstate="collapsed" desc="Generated
    // <editor-fold defaultstate="collapsed" desc="Generated
    // <editor-fold defaultstate="collapsed" desc="Generated
    // <editor-fold defaultstate="collapsed" desc="Generated
    // <editor-fold defaultstate="collapsed" desc="Generated
    // <editor-fold defaultstate="collapsed" desc="Generated
    // <editor-fold defaultstate="collapsed" desc="Generated
    // Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jRadioButtonMenuItem1 = new javax.swing.JRadioButtonMenuItem();
        jSeparator1 = new javax.swing.JSeparator();
        jLayeredPane1 = new javax.swing.JLayeredPane();
        C00 = new javax.swing.JLabel();
        C01 = new javax.swing.JLabel();
        C10 = new javax.swing.JLabel();
        C11 = new javax.swing.JLabel();
        C20 = new javax.swing.JLabel();
        C21 = new javax.swing.JLabel();
        C30 = new javax.swing.JLabel();
        C31 = new javax.swing.JLabel();
        C02 = new javax.swing.JLabel();
        C03 = new javax.swing.JLabel();
        C04 = new javax.swing.JLabel();
        C05 = new javax.swing.JLabel();
        C06 = new javax.swing.JLabel();
        C07 = new javax.swing.JLabel();
        C08 = new javax.swing.JLabel();
        C12 = new javax.swing.JLabel();
        C13 = new javax.swing.JLabel();
        C14 = new javax.swing.JLabel();
        C15 = new javax.swing.JLabel();
        C16 = new javax.swing.JLabel();
        C17 = new javax.swing.JLabel();
        C18 = new javax.swing.JLabel();
        C22 = new javax.swing.JLabel();
        C23 = new javax.swing.JLabel();
        C24 = new javax.swing.JLabel();
        C25 = new javax.swing.JLabel();
        C26 = new javax.swing.JLabel();
        C27 = new javax.swing.JLabel();
        C28 = new javax.swing.JLabel();
        C32 = new javax.swing.JLabel();
        C33 = new javax.swing.JLabel();
        C34 = new javax.swing.JLabel();
        C35 = new javax.swing.JLabel();
        C36 = new javax.swing.JLabel();
        C37 = new javax.swing.JLabel();
        C38 = new javax.swing.JLabel();
        C09Z = new javax.swing.JLabel();
        C19Z = new javax.swing.JLabel();
        C29Z = new javax.swing.JLabel();
        C39Z = new javax.swing.JLabel();
        btnMenu = new javax.swing.JButton();
        cantMonedas = new javax.swing.JLabel();
        jlbMoneda = new javax.swing.JLabel();
        lblPlantaDos = new javax.swing.JLabel();
        lblPlantaUno = new javax.swing.JLabel();
        lbTiempo = new javax.swing.JLabel();
        jProgressBar1 = new javax.swing.JProgressBar();
        jLabel4 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        lbTableroZombies = new javax.swing.JLabel();
        pnlTablero = new javax.swing.JPanel();

        jRadioButtonMenuItem1.setSelected(true);
        jRadioButtonMenuItem1.setText("jRadioButtonMenuItem1");

        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);
        setUndecorated(true);
        setResizable(false);

        jLayeredPane1.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());
        jLayeredPane1.add(C00, new org.netbeans.lib.awtextra.AbsoluteConstraints(107, 256, 70, 80));
        jLayeredPane1.add(C01, new org.netbeans.lib.awtextra.AbsoluteConstraints(180, 250, 70, 90));
        jLayeredPane1.add(C10, new org.netbeans.lib.awtextra.AbsoluteConstraints(110, 340, 70, 90));
        jLayeredPane1.add(C11, new org.netbeans.lib.awtextra.AbsoluteConstraints(180, 340, 70, 90));
        jLayeredPane1.add(C20, new org.netbeans.lib.awtextra.AbsoluteConstraints(110, 440, 70, 80));
        jLayeredPane1.add(C21, new org.netbeans.lib.awtextra.AbsoluteConstraints(190, 440, 70, 80));
        jLayeredPane1.add(C30, new org.netbeans.lib.awtextra.AbsoluteConstraints(100, 520, 80, 100));
        jLayeredPane1.add(C31, new org.netbeans.lib.awtextra.AbsoluteConstraints(180, 530, 80, 90));
        jLayeredPane1.add(C02, new org.netbeans.lib.awtextra.AbsoluteConstraints(250, 250, 80, 90));
        jLayeredPane1.add(C03, new org.netbeans.lib.awtextra.AbsoluteConstraints(330, 250, 80, 90));
        jLayeredPane1.add(C04, new org.netbeans.lib.awtextra.AbsoluteConstraints(410, 250, 70, 90));
        jLayeredPane1.add(C05, new org.netbeans.lib.awtextra.AbsoluteConstraints(480, 250, 80, 90));
        jLayeredPane1.add(C06, new org.netbeans.lib.awtextra.AbsoluteConstraints(560, 250, 80, 90));
        jLayeredPane1.add(C07, new org.netbeans.lib.awtextra.AbsoluteConstraints(630, 250, 80, 90));
        jLayeredPane1.add(C08, new org.netbeans.lib.awtextra.AbsoluteConstraints(710, 250, 90, 90));
        jLayeredPane1.add(C12, new org.netbeans.lib.awtextra.AbsoluteConstraints(250, 340, 80, 100));
        jLayeredPane1.add(C13, new org.netbeans.lib.awtextra.AbsoluteConstraints(330, 340, 80, 100));
        jLayeredPane1.add(C14, new org.netbeans.lib.awtextra.AbsoluteConstraints(410, 340, 70, 100));
        jLayeredPane1.add(C15, new org.netbeans.lib.awtextra.AbsoluteConstraints(480, 340, 90, 100));
        jLayeredPane1.add(C16, new org.netbeans.lib.awtextra.AbsoluteConstraints(560, 340, 70, 100));
        jLayeredPane1.add(C17, new org.netbeans.lib.awtextra.AbsoluteConstraints(630, 340, 80, 100));
        jLayeredPane1.add(C18, new org.netbeans.lib.awtextra.AbsoluteConstraints(710, 340, 90, 100));
        jLayeredPane1.add(C22, new org.netbeans.lib.awtextra.AbsoluteConstraints(260, 440, 80, 80));
        jLayeredPane1.add(C23, new org.netbeans.lib.awtextra.AbsoluteConstraints(340, 440, 80, 80));
        jLayeredPane1.add(C24, new org.netbeans.lib.awtextra.AbsoluteConstraints(410, 440, 80, 80));
        jLayeredPane1.add(C25, new org.netbeans.lib.awtextra.AbsoluteConstraints(480, 440, 80, 80));
        jLayeredPane1.add(C26, new org.netbeans.lib.awtextra.AbsoluteConstraints(560, 440, 80, 80));
        jLayeredPane1.add(C27, new org.netbeans.lib.awtextra.AbsoluteConstraints(630, 440, 90, 80));
        jLayeredPane1.add(C28, new org.netbeans.lib.awtextra.AbsoluteConstraints(710, 440, 90, 80));
        jLayeredPane1.add(C32, new org.netbeans.lib.awtextra.AbsoluteConstraints(260, 520, 80, 100));
        jLayeredPane1.add(C33, new org.netbeans.lib.awtextra.AbsoluteConstraints(340, 520, 70, 100));
        jLayeredPane1.add(C34, new org.netbeans.lib.awtextra.AbsoluteConstraints(410, 520, 80, 100));
        jLayeredPane1.add(C35, new org.netbeans.lib.awtextra.AbsoluteConstraints(490, 520, 80, 100));
        jLayeredPane1.add(C36, new org.netbeans.lib.awtextra.AbsoluteConstraints(560, 520, 80, 100));
        jLayeredPane1.add(C37, new org.netbeans.lib.awtextra.AbsoluteConstraints(640, 520, 80, 100));
        jLayeredPane1.add(C38, new org.netbeans.lib.awtextra.AbsoluteConstraints(710, 520, 100, 100));
        jLayeredPane1.add(C09Z, new org.netbeans.lib.awtextra.AbsoluteConstraints(800, 250, 80, 90));
        jLayeredPane1.add(C19Z, new org.netbeans.lib.awtextra.AbsoluteConstraints(810, 340, 80, 100));
        jLayeredPane1.add(C29Z, new org.netbeans.lib.awtextra.AbsoluteConstraints(810, 440, 90, 80));
        jLayeredPane1.add(C39Z, new org.netbeans.lib.awtextra.AbsoluteConstraints(810, 520, 90, 100));

        btnMenu.setBorder(null);
        btnMenu.setContentAreaFilled(false);
        btnMenu.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnMenuActionPerformed(evt);
            }
        });
        jLayeredPane1.add(btnMenu, new org.netbeans.lib.awtextra.AbsoluteConstraints(830, 80, 180, 30));
        jLayeredPane1.add(cantMonedas, new org.netbeans.lib.awtextra.AbsoluteConstraints(80, 160, 40, 20));

        jlbMoneda.setIcon(new javax.swing.ImageIcon(getClass().getResource("/proyectoed/img/monedaPeq.png"))); // NOI18N
        jlbMoneda.setText("jLabel5");
        jLayeredPane1.add(jlbMoneda, new org.netbeans.lib.awtextra.AbsoluteConstraints(-140, 50, 280, 230));

        lblPlantaDos.setIcon(new javax.swing.ImageIcon(getClass().getResource("/proyectoed/img/BokChoy (1).png"))); // NOI18N
        jLayeredPane1.add(lblPlantaDos, new org.netbeans.lib.awtextra.AbsoluteConstraints(200, 90, -1, 90));

        lblPlantaUno.setIcon(new javax.swing.ImageIcon(getClass().getResource("/proyectoed/img/Peashooter (1).png"))); // NOI18N
        jLayeredPane1.add(lblPlantaUno, new org.netbeans.lib.awtextra.AbsoluteConstraints(140, 90, -1, 90));

        lbTiempo.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        lbTiempo.setForeground(new java.awt.Color(255, 255, 255));
        jLayeredPane1.add(lbTiempo, new org.netbeans.lib.awtextra.AbsoluteConstraints(870, 120, 90, 20));

        jProgressBar1.setBackground(new java.awt.Color(0, 153, 51));
        jProgressBar1.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.LOWERED));
        jProgressBar1.setFocusable(false);
        jLayeredPane1.add(jProgressBar1, new org.netbeans.lib.awtextra.AbsoluteConstraints(570, 100, 240, 30));
        jLayeredPane1.add(jLabel4, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 0, 420, 110));

        jLabel2.setBackground(new java.awt.Color(51, 51, 51));
        jLabel2.setIcon(new javax.swing.ImageIcon(getClass().getResource("/proyectoed/img/ZombieHead.png"))); // NOI18N
        jLabel2.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.LOWERED));
        jLabel2.setOpaque(true);
        jLayeredPane1.add(jLabel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(530, 100, -1, 30));

        lbTableroZombies.setIcon(new javax.swing.ImageIcon(getClass().getResource("/proyectoed/img/FondoNivel.png"))); // NOI18N
        jLayeredPane1.add(lbTableroZombies, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, -1, 785));

        pnlTablero.setOpaque(false);

        javax.swing.GroupLayout pnlTableroLayout = new javax.swing.GroupLayout(pnlTablero);
        pnlTablero.setLayout(pnlTableroLayout);
        pnlTableroLayout.setHorizontalGroup(
                pnlTableroLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                        .addGap(0, 1010, Short.MAX_VALUE));
        pnlTableroLayout.setVerticalGroup(
                pnlTableroLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                        .addGap(0, 780, Short.MAX_VALUE));

        jLayeredPane1.add(pnlTablero, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 1010, 780));

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
                layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                        .addComponent(jLayeredPane1, javax.swing.GroupLayout.PREFERRED_SIZE,
                                javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE));
        layout.setVerticalGroup(
                layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                        .addComponent(jLayeredPane1));

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void btnMenuActionPerformed(java.awt.event.ActionEvent evt) {// GEN-FIRST:event_btnMenuActionPerformed
        frmMenu menu = new frmMenu(usuario);
        menu.setVisible(true);
        this.dispose(); // Cierra el juego actual
    }// GEN-LAST:event_btnMenuActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {

    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JLabel C00;
    private javax.swing.JLabel C01;
    private javax.swing.JLabel C02;
    private javax.swing.JLabel C03;
    private javax.swing.JLabel C04;
    private javax.swing.JLabel C05;
    private javax.swing.JLabel C06;
    private javax.swing.JLabel C07;
    private javax.swing.JLabel C08;
    private javax.swing.JLabel C09Z;
    private javax.swing.JLabel C10;
    private javax.swing.JLabel C11;
    private javax.swing.JLabel C12;
    private javax.swing.JLabel C13;
    private javax.swing.JLabel C14;
    private javax.swing.JLabel C15;
    private javax.swing.JLabel C16;
    private javax.swing.JLabel C17;
    private javax.swing.JLabel C18;
    private javax.swing.JLabel C19Z;
    private javax.swing.JLabel C20;
    private javax.swing.JLabel C21;
    private javax.swing.JLabel C22;
    private javax.swing.JLabel C23;
    private javax.swing.JLabel C24;
    private javax.swing.JLabel C25;
    private javax.swing.JLabel C26;
    private javax.swing.JLabel C27;
    private javax.swing.JLabel C28;
    private javax.swing.JLabel C29Z;
    private javax.swing.JLabel C30;
    private javax.swing.JLabel C31;
    private javax.swing.JLabel C32;
    private javax.swing.JLabel C33;
    private javax.swing.JLabel C34;
    private javax.swing.JLabel C35;
    private javax.swing.JLabel C36;
    private javax.swing.JLabel C37;
    private javax.swing.JLabel C38;
    private javax.swing.JLabel C39Z;
    private javax.swing.JButton btnMenu;
    private javax.swing.JLabel cantMonedas;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLayeredPane jLayeredPane1;
    private javax.swing.JProgressBar jProgressBar1;
    private javax.swing.JRadioButtonMenuItem jRadioButtonMenuItem1;
    private javax.swing.JSeparator jSeparator1;
    private javax.swing.JLabel jlbMoneda;
    private javax.swing.JLabel lbTableroZombies;
    private javax.swing.JLabel lbTiempo;
    private javax.swing.JLabel lblPlantaDos;
    private javax.swing.JLabel lblPlantaUno;
    private javax.swing.JPanel pnlTablero;
    // End of variables declaration//GEN-END:variables

}
