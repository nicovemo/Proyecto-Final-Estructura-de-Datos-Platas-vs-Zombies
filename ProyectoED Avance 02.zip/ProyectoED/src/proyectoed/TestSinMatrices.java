package proyectoed;

import javax.swing.*;
import java.awt.*;

/**
 * Prueba simple sin matrices - solo coordenadas absolutas
 */
public class TestSinMatrices extends JFrame {

    private int plantaSeleccionada = 0;
    private boolean modoSeleccion = false;

    public TestSinMatrices() {
        setTitle("Prueba Sin Matrices - Plants-Fide");
        setSize(600, 500);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);

        // Crear panel principal con fondo
        JPanel mainPanel = new JPanel();
        mainPanel.setLayout(null);
        mainPanel.setBackground(new Color(34, 139, 34)); // Verde oscuro como fondo

        // Crear panel del tablero
        JPanel pnlTablero = new JPanel();
        pnlTablero.setLayout(null);
        pnlTablero.setOpaque(false); // Transparente para ver el fondo
        pnlTablero.setBounds(0, 0, 600, 500);

        // Agregar botones de prueba
        JButton btnPlanta1 = new JButton("Planta 1");
        btnPlanta1.setBounds(50, 50, 120, 30);
        btnPlanta1.addActionListener(e -> {
            System.out.println("Planta 1 seleccionada");
            plantaSeleccionada = 1;
            modoSeleccion = true;
            mainPanel.setCursor(new Cursor(Cursor.CROSSHAIR_CURSOR));
        });

        JButton btnPlanta2 = new JButton("Planta 2");
        btnPlanta2.setBounds(180, 50, 120, 30);
        btnPlanta2.addActionListener(e -> {
            System.out.println("Planta 2 seleccionada");
            plantaSeleccionada = 2;
            modoSeleccion = true;
            mainPanel.setCursor(new Cursor(Cursor.CROSSHAIR_CURSOR));
        });

        // Configurar evento de click en el panel del tablero
        pnlTablero.addMouseListener(new java.awt.event.MouseAdapter() {
            @Override
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                if (modoSeleccion && plantaSeleccionada > 0) {
                    // Usar coordenadas absolutas del click
                    int x = evt.getX();
                    int y = evt.getY();

                    System.out.println("Click en coordenadas (" + x + "," + y + ")");
                    colocarPlantaPrueba(pnlTablero, x, y);

                    // Resetear modo de selección
                    plantaSeleccionada = 0;
                    modoSeleccion = false;
                    mainPanel.setCursor(new Cursor(Cursor.DEFAULT_CURSOR));
                }
            }
        });

        mainPanel.add(btnPlanta1);
        mainPanel.add(btnPlanta2);
        mainPanel.add(pnlTablero);

        add(mainPanel);
    }

    private void colocarPlantaPrueba(JPanel panel, int x, int y) {
        // Crear una etiqueta simple para representar la planta
        JLabel planta = new JLabel("");
        planta.setFont(new Font("Arial", Font.BOLD, 20));
        planta.setHorizontalAlignment(SwingConstants.CENTER);

        // Posicionar la planta en las coordenadas del click
        planta.setBounds(x - 20, y - 20, 40, 40);
        planta.setOpaque(false);
        panel.add(planta);
        panel.setComponentZOrder(planta, 0);
        panel.revalidate();
        panel.repaint();

        System.out.println("Planta colocada en coordenadas (" + x + "," + y + ")");
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            TestSinMatrices test = new TestSinMatrices();
            test.setVisible(true);
            System.out.println("=== PRUEBA SIN MATRICES ===");
            System.out.println("No hay matrices en el código");
            System.out.println("Solo coordenadas absolutas");
            System.out.println("Click directo en cualquier lugar");
            System.out.println("Sistema simplificado");
        });
    }
}