/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package proyectoed;

import java.util.Stack;
import java.util.Random;

/**
 *
 * @author Nicole Venegas
 */
public class PilaZombies {
    private Stack<Zombies> pila1;
    private Stack<Zombies> pila2;
    private Stack<Zombies> pila3;
    private Stack<Zombies> pila4;
    private Random random;

    public PilaZombies() {
        this.pila1 = new Stack<>();
        this.pila2 = new Stack<>();
        this.pila3 = new Stack<>();
        this.pila4 = new Stack<>();
        this.random = new Random();
    }

    /**
     * Llena las 4 pilas de manera aleatoria con la cantidad de zombies especificada
     * 
     * @param cantidadZombies Total de zombies a distribuir entre las pilas
     */
    public void llenarPilasAleatoriamente(int cantidadZombies) {
        // Limpiar las pilas antes de llenarlas
        pila1.clear();
        pila2.clear();
        pila3.clear();
        pila4.clear();

        System.out.println("🧟 Llenando " + cantidadZombies + " zombies en 4 pilas de manera aleatoria...");

        for (int i = 0; i < cantidadZombies; i++) {
            Zombies zombie = new Zombies();
            int pilaAleatoria = random.nextInt(4) + 1; // 1, 2, 3, o 4

            switch (pilaAleatoria) {
                case 1:
                    pila1.push(zombie);
                    System.out.println("  Zombie " + (i + 1) + " agregado a Pila 1");
                    break;
                case 2:
                    pila2.push(zombie);
                    System.out.println("  Zombie " + (i + 1) + " agregado a Pila 2");
                    break;
                case 3:
                    pila3.push(zombie);
                    System.out.println("  Zombie " + (i + 1) + " agregado a Pila 3");
                    break;
                case 4:
                    pila4.push(zombie);
                    System.out.println("  Zombie " + (i + 1) + " agregado a Pila 4");
                    break;
            }
        }

        System.out.println("Distribución final:");
        System.out.println("  Pila 1: " + pila1.size() + " zombies");
        System.out.println("  Pila 2: " + pila2.size() + " zombies");
        System.out.println("  Pila 3: " + pila3.size() + " zombies");
        System.out.println("  Pila 4: " + pila4.size() + " zombies");
    }

    /**
     * Agrega una nueva oleada de zombies a las pilas existentes sin limpiarlas
     * 
     * @param cantidadZombies Total de zombies a distribuir entre las pilas
     */
    public void agregarOleadaAPilas(int cantidadZombies) {
        System.out.println("Agregando " + cantidadZombies + " zombies a las pilas existentes...");

        for (int i = 0; i < cantidadZombies; i++) {
            Zombies zombie = new Zombies();
            int pilaAleatoria = random.nextInt(4) + 1; // 1, 2, 3, o 4

            switch (pilaAleatoria) {
                case 1:
                    pila1.push(zombie);
                    System.out.println("  Zombie " + (i + 1) + " agregado a Pila 1");
                    break;
                case 2:
                    pila2.push(zombie);
                    System.out.println("  Zombie " + (i + 1) + " agregado a Pila 2");
                    break;
                case 3:
                    pila3.push(zombie);
                    System.out.println("  Zombie " + (i + 1) + " agregado a Pila 3");
                    break;
                case 4:
                    pila4.push(zombie);
                    System.out.println("  Zombie " + (i + 1) + " agregado a Pila 4");
                    break;
            }
        }

        System.out.println("Estado actualizado de las pilas:");
        System.out.println("  Pila 1: " + pila1.size() + " zombies");
        System.out.println("  Pila 2: " + pila2.size() + " zombies");
        System.out.println("  Pila 3: " + pila3.size() + " zombies");
        System.out.println("  Pila 4: " + pila4.size() + " zombies");
    }

    /**
     * Obtiene un zombie de la pila especificada
     * 
     * @param numeroPila Número de pila (1-4)
     * @return El zombie en la cima de la pila, o null si está vacía
     */
    public Zombies obtenerZombieDePila(int numeroPila) {
        switch (numeroPila) {
            case 1:
                return pila1.isEmpty() ? null : pila1.pop();
            case 2:
                return pila2.isEmpty() ? null : pila2.pop();
            case 3:
                return pila3.isEmpty() ? null : pila3.pop();
            case 4:
                return pila4.isEmpty() ? null : pila4.pop();
            default:
                return null;
        }
    }

    /**
     * Verifica si una pila específica está vacía
     * 
     * @param numeroPila Número de pila (1-4)
     * @return true si la pila está vacía, false en caso contrario
     */
    public boolean pilaVacia(int numeroPila) {
        switch (numeroPila) {
            case 1:
                return pila1.isEmpty();
            case 2:
                return pila2.isEmpty();
            case 3:
                return pila3.isEmpty();
            case 4:
                return pila4.isEmpty();
            default:
                return true;
        }
    }

    /**
     * Obtiene el tamaño de una pila específica
     * 
     * @param numeroPila Número de pila (1-4)
     * @return El número de zombies en la pila
     */
    public int getTamanioPila(int numeroPila) {
        switch (numeroPila) {
            case 1:
                return pila1.size();
            case 2:
                return pila2.size();
            case 3:
                return pila3.size();
            case 4:
                return pila4.size();
            default:
                return 0;
        }
    }

    /**
     * Verifica si todas las pilas están vacías
     * 
     * @return true si todas las pilas están vacías, false en caso contrario
     */
    public boolean todasLasPilasVacias() {
        return pila1.isEmpty() && pila2.isEmpty() && pila3.isEmpty() && pila4.isEmpty();
    }

    /**
     * Obtiene el total de zombies en todas las pilas
     * 
     * @return El número total de zombies
     */
    public int getTotalZombies() {
        return pila1.size() + pila2.size() + pila3.size() + pila4.size();
    }

    /**
     * Obtiene información del estado de todas las pilas
     * 
     * @return String con el estado de cada pila
     */
    public String getEstadoPilas() {
        return String.format("Pila 1: %d | Pila 2: %d | Pila 3: %d | Pila 4: %d | Total: %d",
                pila1.size(), pila2.size(), pila3.size(), pila4.size(), getTotalZombies());
    }
}