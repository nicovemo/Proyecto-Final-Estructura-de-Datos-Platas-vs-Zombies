/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package proyectoed;

import javax.swing.ImageIcon;
import javax.swing.JLabel;

/**
 *
 * @author Nicole Venegas
 */
public abstract class Planta {
    protected int vida;
    protected int costo;
    protected int fila;
    protected int columna;
    protected ImageIcon icono;
    protected JLabel componenteVisual;

    public Planta(int vida, int costo, String rutaIcono) {
        this.vida = vida;
        this.costo = costo;
        this.fila = -1;
        this.columna = -1;

        // Manejar la carga de imagen de forma segura
        try {
            this.icono = new ImageIcon(getClass().getResource(rutaIcono));
            if (this.icono.getImage() == null) {
                // Si no se puede cargar la imagen, crear un icono por defecto
                this.icono = new ImageIcon();
            }
        } catch (Exception e) {
            // Si hay error, crear un icono por defecto
            this.icono = new ImageIcon();
        }

        this.componenteVisual = new JLabel(icono);
        this.componenteVisual.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        this.componenteVisual.setVerticalAlignment(javax.swing.SwingConstants.CENTER);
        this.componenteVisual.setOpaque(false);
    }

    public abstract void atacar(ListaZombies zombies);

    public abstract void recibirDanio(int danio);

    public int getVida() {
        return vida;
    }

    public int getCosto() {
        return costo;
    }

    public int getFila() {
        return fila;
    }

    public int getColumna() {
        return columna;
    }

    public void setPosicion(int fila, int columna) {
        this.fila = fila;
        this.columna = columna;
    }

    public JLabel getComponenteVisual() {
        return componenteVisual;
    }

    protected void actualizarComponenteVisual() {
        componenteVisual.setIcon(icono);
        componenteVisual.revalidate();
        componenteVisual.repaint();
    }

    public boolean estaViva() {
        return vida > 0;
    }
}
