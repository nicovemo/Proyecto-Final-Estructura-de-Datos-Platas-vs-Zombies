/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package proyectoed;

/**
 *
 * @author PC-JPS01
 */
public class ListaZombies {
    private NodoZombie cabeza;
    private NodoZombie cola;
    private int size;

    Zombies obtener(int i) {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from
                                                                       // nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    // Clase interna para los nodos
    private static class NodoZombie {
        Zombies zombie;
        NodoZombie siguiente;
        int fila;
        int columna;

        public NodoZombie(Zombies zombie, int fila, int columna) {
            this.zombie = zombie;
            this.fila = fila;
            this.columna = columna;
            this.siguiente = null;
        }
    }

    public ListaZombies() {
        this.cabeza = null;
        this.cola = null;
        this.size = 0;
    }

    /**
     * Agrega un zombie al final de la lista
     */
    public void agregar(Zombies zombie, int fila, int columna) {
        NodoZombie nuevoNodo = new NodoZombie(zombie, fila, columna);

        if (cabeza == null) {
            cabeza = nuevoNodo;
            cola = nuevoNodo;
        } else {
            cola.siguiente = nuevoNodo;
            cola = nuevoNodo;
        }
        size++;
    }

    /**
     * Mueve todos los zombies una posición hacia la izquierda
     * y maneja las colisiones con plantas
     */
    public void mover(ListaPlantas plantas) {
        NodoZombie actual = cabeza;
        NodoZombie anterior = null;

        while (actual != null) {
            // Verificar si hay planta en la posición siguiente
            if (plantas.hayPlantaEn(actual.fila, actual.columna - 1)) {
                // Atacar a la planta
                Planta planta = plantas.obtenerPlantaEn(actual.fila, actual.columna - 1);
                planta.recibirDanio(actual.zombie.getDano());

                // Si la planta fue destruida
                if (planta.getVida() <= 0) {
                    plantas.eliminar(actual.fila, actual.columna - 1);
                }
            } else {
                // Mover el zombie
                actual.columna--;

                // Verificar si llegó al final del tablero (columna < 0)
                if (actual.columna < 0) {
                    if (anterior == null) {
                        cabeza = actual.siguiente;
                    } else {
                        anterior.siguiente = actual.siguiente;
                    }

                    if (actual == cola) {
                        cola = anterior;
                    }

                    size--;
                    continue;
                }
            }

            anterior = actual;
            actual = actual.siguiente;
        }
    }

    /**
     * Verifica si algún zombie llegó al final del tablero
     */
    public boolean algunoLlegoAlFinal() {
        NodoZombie actual = cabeza;

        while (actual != null) {
            if (actual.columna < 0) {
                return true;
            }
            actual = actual.siguiente;
        }

        return false;
    }

    /**
     * Elimina un zombie de la lista cuando es destruido
     */
    public boolean eliminar(int fila, int columna) {
        NodoZombie actual = cabeza;
        NodoZombie anterior = null;

        while (actual != null) {
            if (actual.fila == fila && actual.columna == columna) {
                if (anterior == null) {
                    cabeza = actual.siguiente;
                } else {
                    anterior.siguiente = actual.siguiente;
                }

                if (actual == cola) {
                    cola = anterior;
                }

                size--;
                return true;
            }

            anterior = actual;
            actual = actual.siguiente;
        }

        return false;
    }

    /**
     * Verifica si la lista está vacía
     */
    public boolean estaVacia() {
        return cabeza == null;
    }

    /**
     * Obtiene el tamaño de la lista
     */
    public int getSize() {
        return size;
    }

    /**
     * Obtiene un zombie en una posición específica
     */
    public Zombies obtener(int fila, int columna) {
        NodoZombie actual = cabeza;

        while (actual != null) {
            if (actual.fila == fila && actual.columna == columna) {
                return actual.zombie;
            }
            actual = actual.siguiente;
        }

        return null;
    }

    /**
     * Aplica daño a un zombie en una posición específica
     * y lo elimina si su vida llega a cero
     */
    public boolean aplicarDanio(int fila, int columna, int danio) {
        NodoZombie actual = cabeza;

        while (actual != null) {
            if (actual.fila == fila && actual.columna == columna) {
                actual.zombie.recibirDanio(danio);

                if (actual.zombie.getVida() <= 0) {
                    eliminar(fila, columna);
                    return true; // Zombie eliminado
                }
                return false; // Zombie herido pero no eliminado
            }
            actual = actual.siguiente;
        }

        return false; // No se encontró el zombie
    }

    /**
     * Obtiene todos los zombies en una fila específica
     */
    public Zombies[] obtenerZombiesEnFila(int fila) {
        Zombies[] zombies = new Zombies[size];
        int index = 0;
        NodoZombie actual = cabeza;

        while (actual != null) {
            if (actual.fila == fila) {
                zombies[index++] = actual.zombie;
            }
            actual = actual.siguiente;
        }

        // Redimensionar el array si es necesario
        if (index < zombies.length) {
            Zombies[] resultado = new Zombies[index];
            System.arraycopy(zombies, 0, resultado, 0, index);
            return resultado;
        }

        return zombies;
    }

    /**
     * Limpia toda la lista de zombies
     */
    public void vaciar() {
        cabeza = null;
        cola = null;
        size = 0;
    }
}
