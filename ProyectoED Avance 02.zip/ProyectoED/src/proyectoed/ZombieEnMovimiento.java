/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package proyectoed;

import javax.swing.JLabel;
import javax.swing.ImageIcon;
import java.awt.Image;

/**
 *
 * @author Nicole Venegas
 */
public class ZombieEnMovimiento {
    private Zombies zombie;
    private int fila; // 0-3 (fila del tablero)
    private int columna; // 0-8 (columna del tablero, 0 es la más a la izquierda)
    private JLabel labelActual;
    private boolean activo;
    private int numeroPila; // De qué pila vino (1-4)

    public ZombieEnMovimiento(Zombies zombie, int fila, int numeroPila) {
        this.zombie = zombie;
        this.fila = fila;
        this.columna = 8; // Empieza en la columna más a la derecha (C08, C18, C28, C38)
        this.numeroPila = numeroPila;
        this.activo = true;
        this.labelActual = null;
    }

    public Zombies getZombie() {
        return zombie;
    }

    public int getFila() {
        return fila;
    }

    public int getColumna() {
        return columna;
    }

    public JLabel getLabelActual() {
        return labelActual;
    }

    public void setLabelActual(JLabel labelActual) {
        this.labelActual = labelActual;
    }

    public boolean isActivo() {
        return activo;
    }

    public void setActivo(boolean activo) {
        this.activo = activo;
    }

    public int getNumeroPila() {
        return numeroPila;
    }

    /**
     * Mueve el zombie una columna hacia la izquierda
     * 
     * @return true si se pudo mover, false si se detuvo
     */
    public boolean mover() {
        if (!activo || columna <= 0) {
            return false; // No se puede mover más a la izquierda
        }

        columna--;
        return true;
    }

    /**
     * Obtiene el nombre del label correspondiente a la posición actual
     * 
     * @return El nombre del label (ej: "C08", "C07", etc.)
     */
    public String getNombreLabel() {
        return "C" + fila + columna;
    }

    /**
     * Verifica si el zombie puede moverse (no está en la columna más a la
     * izquierda)
     * 
     * @return true si puede moverse, false en caso contrario
     */
    public boolean puedeMoverse() {
        return columna > 0;
    }

    /**
     * Verifica si el zombie está lo suficientemente lejos para introducir uno nuevo
     * 
     * @return true si está al menos 3 espacios atrás, false en caso contrario
     */
    public boolean estaLejosParaNuevoZombie() {
        return columna <= 5; // Si está en C05 o más a la izquierda
    }

    /**
     * Obtiene la posición en la matriz [fila][columna]
     * 
     * @return Array con [fila, columna]
     */
    public int[] getPosicionMatriz() {
        return new int[] { fila, columna };
    }

    @Override
    public String toString() {
        return "ZombieEnMovimiento{fila=" + fila + ", columna=" + columna +
                ", label=" + getNombreLabel() + ", pila=" + numeroPila +
                ", activo=" + activo + "}";
    }
}