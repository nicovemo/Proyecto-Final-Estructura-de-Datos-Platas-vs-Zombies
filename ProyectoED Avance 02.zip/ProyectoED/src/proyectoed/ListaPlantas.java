/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package proyectoed;

/**
 *
 * @author Nicole Venegas
 */
public class ListaPlantas {
    private NodoPlanta cabeza;

    private static class NodoPlanta {
        Planta planta;
        NodoPlanta siguiente;

        public NodoPlanta(Planta planta) {
            this.planta = planta;
            this.siguiente = null;
        }
    }

    public boolean agregar(Planta planta, int fila, int columna) {
        // Verificar si la posición está ocupada
        if (hayPlantaEn(fila, columna)) {
            return false;
        }

        planta.setPosicion(fila, columna);
        NodoPlanta nuevoNodo = new NodoPlanta(planta);

        if (cabeza == null) {
            cabeza = nuevoNodo;
        } else {
            NodoPlanta actual = cabeza;
            while (actual.siguiente != null) {
                actual = actual.siguiente;
            }
            actual.siguiente = nuevoNodo;
        }
        return true;
    }

    public boolean hayPlantaEn(int fila, int columna) {
        NodoPlanta actual = cabeza;

        while (actual != null) {
            if (actual.planta.getFila() == fila && actual.planta.getColumna() == columna) {
                return true;
            }
            actual = actual.siguiente;
        }

        return false;
    }

    public Planta obtenerPlantaEn(int fila, int columna) {
        NodoPlanta actual = cabeza;

        while (actual != null) {
            if (actual.planta.getFila() == fila && actual.planta.getColumna() == columna) {
                return actual.planta;
            }
            actual = actual.siguiente;
        }

        return null;
    }

    public void eliminar(int fila, int columna) {
        NodoPlanta actual = cabeza;
        NodoPlanta anterior = null;

        while (actual != null) {
            if (actual.planta.getFila() == fila && actual.planta.getColumna() == columna) {
                if (anterior == null) {
                    cabeza = actual.siguiente;
                } else {
                    anterior.siguiente = actual.siguiente;
                }
                return;
            }
            anterior = actual;
            actual = actual.siguiente;
        }
    }

    public void atacar(ListaZombies zombies) {
        NodoPlanta actual = cabeza;

        while (actual != null) {
            if (actual.planta.estaViva()) {
                actual.planta.atacar(zombies);
            }
            actual = actual.siguiente;
        }
    }

    public void vaciar() {
        cabeza = null;
    }

    public void moverProyectiles(ListaZombies zombies) {
        // Implementación del movimiento de proyectiles
    }
}
