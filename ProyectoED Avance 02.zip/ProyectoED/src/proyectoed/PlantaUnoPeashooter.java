/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package proyectoed;

import javax.swing.ImageIcon;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.SwingUtilities;

/**
 *
 * @author Nicole Venegas
 */
public class PlantaUnoPeashooter extends Planta {
    private int danioProyectil;
    private boolean proyectilDisponible;
    private int vida;
    private ImageIcon icono;
    private int fila;
    private int columna;

    public PlantaUnoPeashooter() {
        super(5, 250, "/proyectoed/img/pea-shooter-plant-vs-zombie-ezgif.com-resize.gif");
        this.danioProyectil = 2;
        this.proyectilDisponible = true;

        // Configurar el componente visual para que se vea mejor
        if (componenteVisual != null) {
            componenteVisual.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
            componenteVisual.setVerticalAlignment(javax.swing.SwingConstants.CENTER);
        }
    }

    public void atacar(ListaZombies zombies) {
        if (!proyectilDisponible)
            return;

        Zombies zombieObjetivo = null;
        int columnaMasCercana = Integer.MAX_VALUE;

        for (int c = columna + 1; c < 10; c++) {
            Zombies z = zombies.obtener(fila, c);
            if (z != null) {
                zombieObjetivo = z;
                columnaMasCercana = c;
                break;
            }
        }
        if (zombieObjetivo != null) {
            // 1. Crear el proyectil
            JLabel proyectil = new JLabel(new ImageIcon(getClass().getResource("/img/proyectil.png")));

            // 2. Variables que se usarán en el lambda deben ser final/effectively final
            final int columnaFinal = columna; // Hacer copia final
            final int filaFinal = fila; // Hacer copia final
            final int columnaMasCercanaFinal = columnaMasCercana; // Copia final

            proyectil.setBounds(columna * 50 + 50, fila * 50, 20, 20);

            // 3. Animación del proyectil
            new Thread(() -> {
                try {
                    for (int i = columnaFinal + 1; i <= columnaMasCercanaFinal; i++) {
                        final int pos = i;
                        SwingUtilities.invokeLater(() -> {
                            proyectil.setBounds(pos * 50, filaFinal * 50, 20, 20);
                        });
                        Thread.sleep(100);
                    }

                    // 4. Aplicar daño al zombie
                    zombies.aplicarDanio(filaFinal, columnaMasCercanaFinal, danioProyectil);

                    // 5. Eliminar proyectil
                    SwingUtilities.invokeLater(() -> {
                        ((JPanel) proyectil.getParent()).remove(proyectil);
                        proyectil.getParent().revalidate();
                        proyectil.getParent().repaint();
                    });
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
            }).start();

        }
    }

    public void recibirDanio(int danio) {
        vida -= danio;
        if (vida <= 0) {
            icono = new ImageIcon(getClass().getResource("/images/planta_muerta.gif"));
            actualizarComponenteVisual();
        }
    }

    protected void actualizarComponenteVisual() {

    }

}
