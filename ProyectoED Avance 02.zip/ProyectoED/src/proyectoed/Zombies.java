/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package proyectoed;

import javax.swing.*;

/**
 *
 * @author Nicole Venegas
 */
public class Zombies {
    private int vida;
    private int dano;
    private int recompensa;
    private ImageIcon icono;
    public String nombre;

    public Zombies() {
        this.vida = 6;
        this.dano = 3;
        this.recompensa = 300;
        this.fila = -1;
        this.columna = -1;

        // Cargar icono según el tipo de zombie
        try {
            this.icono = new ImageIcon(getClass().getResource("/proyectoed/img/Zombie.png"));
            if (this.icono.getImage() == null) {
                this.icono = new ImageIcon();
            }
        } catch (Exception e) {
            this.icono = new ImageIcon();
        }
    }

    public void recibirDanio(int danio) {
        this.vida -= danio;
    }

    public int getVida() {
        return vida;
    }

    public int getDano() {
        return dano;
    }

    public int getRecompensa() {
        return recompensa;
    }

    public ImageIcon getIcono() {
        return icono;
    }

    // Método para cambiar a zombie alien (si hay diferentes tipos)
    public void convertirEnAlien() {
        this.dano = 4;
        this.vida = 8;
        try {
            this.icono = new ImageIcon(getClass().getResource("/proyectoed/img/Zombie.png"));
            if (this.icono.getImage() == null) {
                this.icono = new ImageIcon();
            }
        } catch (Exception e) {
            this.icono = new ImageIcon();
        }
    }

    private int fila;
    private int columna;

    public int getFila() {
        return fila;
    }

    public void setFila(int fila) {
        this.fila = fila;
    }

    public int getColumna() {
        return columna;
    }

    public void setColumna(int columna) {
        this.columna = columna;
    }
}
