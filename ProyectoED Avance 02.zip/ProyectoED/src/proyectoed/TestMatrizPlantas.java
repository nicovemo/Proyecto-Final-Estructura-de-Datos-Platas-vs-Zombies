/*
 * Test para verificar la funcionalidad de la matriz de plantas
 */
package proyectoed;

import javax.swing.*;
import java.awt.*;

public class TestMatrizPlantas {

    public static void main(String[] args) {
        // Crear una ventana de prueba
        JFrame frame = new JFrame("Test Matriz Plantas");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setSize(400, 300);

        // Crear una instancia del juego para probar
        frmJuego juego = new frmJuego("UsuarioTest");

        // Panel principal
        JPanel panel = new JPanel();
        panel.setLayout(new GridLayout(3, 1, 10, 10));

        // Botón para mostrar información de la matriz
        JButton btnMostrarInfo = new JButton("Mostrar Información de Matriz");
        btnMostrarInfo.addActionListener(e -> {
            System.out.println("\n=== PRUEBA DE MATRIZ ===");
            juego.mostrarInformacionMatriz();
            juego.imprimirEstadoMatriz();
        });

        // Botón para limpiar matriz
        JButton btnLimpiar = new JButton("Limpiar Matriz");
        btnLimpiar.addActionListener(e -> {
            juego.limpiarMatriz();
            System.out.println("Matriz limpiada");
        });

        // Botón para simular colocación de plantas
        JButton btnSimular = new JButton("Simular Colocación de Plantas");
        btnSimular.addActionListener(e -> {
            simularColocacionPlantas(juego);
        });

        panel.add(btnMostrarInfo);
        panel.add(btnLimpiar);
        panel.add(btnSimular);

        frame.add(panel);
        frame.setLocationRelativeTo(null);
        frame.setVisible(true);

        System.out.println("🧪 Test de Matriz Plantas iniciado");
        System.out.println("Instrucciones:");
        System.out.println("1. Haz clic en 'Mostrar Información de Matriz' para ver el estado actual");
        System.out.println("2. Haz clic en 'Limpiar Matriz' para limpiar todas las plantas");
        System.out.println("3. Haz clic en 'Simular Colocación de Plantas' para probar la funcionalidad");
    }

    private static void simularColocacionPlantas(frmJuego juego) {
        System.out.println("\nSIMULANDO COLOCACIÓN DE PLANTAS");
        System.out.println("==================================");

        // Simular colocación de plantas en diferentes posiciones
        String[] posiciones = { "C00", "C01", "C10", "C11", "C20", "C21", "C30", "C31" };

        for (int i = 0; i < posiciones.length; i++) {
            String posicion = posiciones[i];
            int tipoPlanta = (i % 2 == 0) ? 1 : 2; // Alternar entre PlantaUno y PlantaDos

            System.out.println("Colocando planta tipo " + tipoPlanta + " en posición " + posicion);

            // Simular la selección de planta
            juego.plantaSeleccionada = tipoPlanta;
            juego.modoSeleccion = true;

            // Simular la colocación (esto es solo para demostración)
            System.out.println("✅ Simulación completada para " + posicion);
        }

        System.out.println("==================================");
        System.out.println("Para probar la funcionalidad real, ejecuta el juego y coloca plantas manualmente");
    }
}