package proyectoed;

import java.io.File;
import java.io.IOException;
import javax.sound.sampled.AudioInputStream;
import javax.sound.sampled.AudioSystem;
import javax.sound.sampled.Clip;
import javax.sound.sampled.LineUnavailableException;
import javax.sound.sampled.UnsupportedAudioFileException;

/**
 * Clase para manejar la reproducción de audio de fondo
 */
public class AudioManager {
    private static AudioManager instance;
    private Clip backgroundMusic;
    private boolean isPlaying = false;

    private AudioManager() {
        // Constructor privado para singleton
    }

    public static AudioManager getInstance() {
        if (instance == null) {
            instance = new AudioManager();
        }
        return instance;
    }

    /**
     * Inicia la reproducción de música de fondo en bucle
     * 
     * @param audioPath Ruta del archivo de audio
     */
    public void playBackgroundMusic(String audioPath) {
        if (isPlaying) {
            return; // Ya está reproduciéndose
        }

        try {
            // Cargar el archivo de audio
            AudioInputStream audioInputStream = AudioSystem.getAudioInputStream(new File(audioPath));
            backgroundMusic = AudioSystem.getClip();
            backgroundMusic.open(audioInputStream);

            // Configurar para reproducir en bucle
            backgroundMusic.loop(Clip.LOOP_CONTINUOUSLY);
            isPlaying = true;

            System.out.println("Musica de fondo iniciada: " + audioPath);

        } catch (UnsupportedAudioFileException | IOException | LineUnavailableException e) {
            System.out.println("Error al reproducir musica de fondo: " + e.getMessage());
        }
    }

    /**
     * Detiene la música de fondo
     */
    public void stopBackgroundMusic() {
        if (backgroundMusic != null && isPlaying) {
            backgroundMusic.stop();
            backgroundMusic.close();
            isPlaying = false;
            System.out.println("Musica de fondo detenida");
        }
    }

    /**
     * Pausa la música de fondo
     */
    public void pauseBackgroundMusic() {
        if (backgroundMusic != null && isPlaying) {
            backgroundMusic.stop();
            System.out.println("Musica de fondo pausada");
        }
    }

    /**
     * Reanuda la música de fondo
     */
    public void resumeBackgroundMusic() {
        if (backgroundMusic != null && !isPlaying) {
            backgroundMusic.loop(Clip.LOOP_CONTINUOUSLY);
            isPlaying = true;
            System.out.println("Musica de fondo reanudada");
        }
    }

    /**
     * Reproduce un efecto de sonido una vez (sin interrumpir la música de fondo)
     * 
     * @param audioPath Ruta del archivo de audio
     */
    public void playSoundEffect(String audioPath) {
        try {
            AudioInputStream audioInputStream = AudioSystem.getAudioInputStream(new File(audioPath));
            Clip soundEffect = AudioSystem.getClip();
            soundEffect.open(audioInputStream);
            soundEffect.start();

            System.out.println("Efecto de sonido reproducido: " + audioPath);

        } catch (UnsupportedAudioFileException | IOException | LineUnavailableException e) {
            System.out.println("Error al reproducir efecto de sonido: " + e.getMessage());
        }
    }

    /**
     * Verifica si la música de fondo está reproduciéndose
     * 
     * @return true si está reproduciéndose, false en caso contrario
     */
    public boolean isBackgroundMusicPlaying() {
        return isPlaying;
    }
}