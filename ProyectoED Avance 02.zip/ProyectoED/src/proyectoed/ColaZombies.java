/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package proyectoed;

/**
 *
 * @author Nicole Venegas
 */
public class ColaZombies {
    private Nodo<Zombies> frente;
    private Nodo<Zombies> fin;

    public void encolar(Zombies z) {
        Nodo<Zombies> nuevo = new Nodo<>(z);
        if (frente == null) {
            frente = nuevo;
            fin = nuevo;
        } else {
            fin.siguiente = nuevo;
            fin = nuevo;
        }
    }

    public Zombies desencolar() {
        if (frente == null)
            return null;
        Zombies eliminado = frente.dato;
        frente = frente.siguiente;
        if (frente == null)
            fin = null;
        return eliminado;
    }

    public boolean estaVacia() {
        return frente == null;
    }

    public Zombies[] obtenerSiguientes(int cantidad) {
        if (estaVacia()) {
            return new Zombies[0];
        }

        Zombies[] siguientes = new Zombies[Math.min(cantidad, getTamanio())];
        Nodo<Zombies> actual = frente;
        int index = 0;

        while (actual != null && index < cantidad) {
            siguientes[index] = actual.dato;
            actual = actual.siguiente;
            index++;
        }

        return siguientes;
    }

    public int getTamanio() {
        int contador = 0;
        Nodo<Zombies> actual = frente;
        while (actual != null) {
            contador++;
            actual = actual.siguiente;
        }
        return contador;
    }
}