/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package proyectoed;

import javax.swing.ImageIcon;

/**
 *
 * @author Nicole Venegas
 */
public class PlantaDosBokchoy extends Planta {
    private int danio;
    private int columna;
    private int fila;
    private ImageIcon icono;
    private int vida;

    public PlantaDosBokchoy() {
        super(7, 400, "/proyectoed/img/bokchoy-ezgif.com-resize (1).gif");
        this.danio = 3;

        // Configurar el componente visual para que se vea mejor
        if (componenteVisual != null) {
            componenteVisual.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
            componenteVisual.setVerticalAlignment(javax.swing.SwingConstants.CENTER);
        }
    }

    public void atacar(ListaZombies zombies) {
        Zombies zombieObjetivo = zombies.obtener(fila, columna + 1);

        if (zombieObjetivo != null) {
            zombieObjetivo.recibirDanio(danio);

            icono = new ImageIcon(getClass().getResource("/images/planta_cuerpo_ataque.png"));
            actualizarComponenteVisual();

            new javax.swing.Timer(500, e -> {
                icono = new ImageIcon(getClass().getResource("/images/bokchoy-ezgif.com-resize (1).gif"));
                actualizarComponenteVisual();
                ((javax.swing.Timer) e.getSource()).stop();
            }).start();
        }
    }

    public void recibirDanio(int danio) {
        vida -= danio;
        if (vida <= 0) {
            icono = new ImageIcon(getClass().getResource("/images/planta_muerta.png"));
            actualizarComponenteVisual();
        } else {
            icono = new ImageIcon(getClass().getResource("/images/planta_cuerpo_danio.png"));
            actualizarComponenteVisual();

            new javax.swing.Timer(300, e -> {
                icono = new ImageIcon(getClass().getResource("/images/bokchoy-ezgif.com-resize (1).gif"));
                actualizarComponenteVisual();
                ((javax.swing.Timer) e.getSource()).stop();
            }).start();
        }
    }

    protected void actualizarComponenteVisual() {

    }
}
